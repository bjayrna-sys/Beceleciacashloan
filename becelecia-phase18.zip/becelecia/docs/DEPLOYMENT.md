# Deployment guide – Becelecia Cashloan

The system is a single Python program (no packages needed to run it; `pip install -r requirements.txt` adds PDF and Excel export) with a SQLite database file. It is suited to one business at this scale. It runs behind **nginx** which provides HTTPS.

## 1. Try it on your own computer
    cd backend && python3 server.py        # then open http://localhost:8000
Pages: `/` website · `/portal` customers · `/investor` investors · `/staff` staff.
Demo logins (password `Demo@1234`): admin@demo.com, officer@demo.com, cashier@demo.com, accountant@demo.com. **Delete or disable them before going live.**

## 2. Put it on a server (Ubuntu 22.04/24.04, small VPS is enough)
    sudo apt update && sudo apt install -y python3 python3-pip nginx certbot python3-certbot-nginx
    sudo adduser --system --group --home /opt/becelecia becelecia
    # copy the project to /opt/becelecia (so /opt/becelecia/backend/server.py exists)
    sudo pip3 install -r /opt/becelecia/requirements.txt --break-system-packages
    sudo mkdir -p /var/lib/becelecia/{database,uploads} /var/backups/becelecia
    sudo chown -R becelecia:becelecia /var/lib/becelecia /var/backups/becelecia /opt/becelecia
    sudo cp /opt/becelecia/deploy/becelecia.env.example /etc/becelecia.env
    sudo nano /etc/becelecia.env              # set WEBHOOK_SECRET to a long random value
    sudo chmod 600 /etc/becelecia.env
    sudo cp /opt/becelecia/deploy/becelecia.service /etc/systemd/system/
    sudo systemctl enable --now becelecia
    curl http://127.0.0.1:8000/api/health     # should show {"status": "ok"}

## 3. Domain and HTTPS
1. At your domain registrar point `beceleciacashloan.com` and `www` (an **A record**) to the server's IP address.
2. `sudo cp /opt/becelecia/deploy/nginx.conf /etc/nginx/sites-available/becelecia && sudo ln -s /etc/nginx/sites-available/becelecia /etc/nginx/sites-enabled/ && sudo nginx -t && sudo systemctl reload nginx`
3. `sudo certbot --nginx -d beceleciacashloan.com -d www.beceleciacashloan.com` (free certificate, renews automatically).
4. Firewall: `sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable`. The app itself listens only on 127.0.0.1.

## 4. First-time setup in the staff console (`/staff`)
1. Log in as admin → **Users**: create your real admin and staff; change your password; disable the demo users.
2. **Settings**: check company details, interest, fees, penalties, grace period, investor %.
3. **Finance → Set opening balances.** **Investors**: add investors and record deposits.
4. Test a full cycle with a small real loan before opening to customers.

## 5. Updating
1. `python3 backup.py` (see BACKUP.md). 2. Copy new files over `/opt/becelecia`. 3. `sudo systemctl restart becelecia`. Logged-in users must log in again after a restart.

## 6. Going-live checklist
- [ ] HTTPS working, demo users disabled, strong admin passwords
- [ ] `WEBHOOK_SECRET` changed; `/etc/becelecia.env` is `chmod 600`
- [ ] Nightly backup + off-server copy running, and **a restore tested**
- [ ] Privacy Policy and Terms reviewed by a lawyer
- [ ] NAMFISA report fields checked against your official reporting requirements
- [ ] Online payments stay in TEST mode until a real payment provider is connected (none is connected yet)

## 7. Known limits (be aware)
- One server process only (sessions are held in memory; a restart logs everyone out).
- SQLite, not PostgreSQL; fine for a single shop's volume, but plan a migration if you grow a lot.
- Email, SMS and WhatsApp are not sent automatically; staff send from the "Messages to send" list.
- Login rate limiting is per account, not per IP; consider also using nginx `limit_req`.
- Document and report download links carry the login token in the address; keep sessions on trusted devices.

## 8. If you are locked out
Run these on the server (they work without logging in):
    cd /opt/becelecia/backend && set -a && . /etc/becelecia.env && set +a
    python3 recover.py disable-forced-2fa            # e.g. email stopped working and admins are asked for a code they cannot receive
    python3 recover.py reset-password admin@yourdomain.com
Required two-step login needs working email. Before switching it on, send a test email in the staff console; the system also asks you to confirm with an emailed code first.
