# Backups – Becelecia Cashloan

Everything you must not lose lives in two places: the **database** (customers, loans, payments, receipts, audit log) and the **uploads folder** (IDs, payslips, bank statements, proofs). `backup.py` saves both together in one file.

## Make a backup
    cd /opt/becelecia/backend && python3 backup.py
Writes `becelecia-backup-YYYYMMDD-HHMMSS.tar.gz` to `BACKUP_DIR` and keeps the newest 30 (`--keep N` to change). It is safe to run while the system is in use.

## How often
| What | When |
|---|---|
| Full backup (database + documents) | **Every night** (cron below) |
| Extra backup | **Before every update or settings/rate change** |
| Copy off the server | **Every night**, to a different place (other computer, cloud storage or another server) |
| Keep | last 30 daily; also keep one backup per month for 12 months (copy it aside) |
| Test a restore | **Once a month** on a spare computer |

Cron (as the becelecia user, `crontab -e`):
    30 1 * * * set -a; . /etc/becelecia.env; set +a; cd /opt/becelecia/backend && python3 backup.py >> /var/log/becelecia-backup.log 2>&1
    0 2 * * *  rsync -a /var/backups/becelecia/ backupuser@other-server:/backups/becelecia/

## Restore
1. Stop the system: `sudo systemctl stop becelecia`
2. `cd /opt/becelecia/backend && python3 restore.py /var/backups/becelecia/becelecia-backup-XXXX.tar.gz`
3. Type `YES`. Your current data is first saved as a `pre-restore-…` backup, and the backup is checked for damage before anything is replaced.
4. Start again: `sudo systemctl start becelecia`, log in and check recent loans and payments.
Everything after the backup time is lost, so restore the newest good backup.

## Protect the backup files
- They contain customers' IDs and financial data. Keep them `chmod 700` folder / `600` files (done automatically) and **never** put them on a public website or share by WhatsApp or email.
- Encrypt them: install `gpg`, put a long passphrase in `/etc/becelecia.backup-pass` (`chmod 600`) and set `BACKUP_PASSPHRASE_FILE=/etc/becelecia.backup-pass`. Backups become `.tar.gz.gpg`. **Store the passphrase separately (e.g. printed in a safe) – without it the backups cannot be opened.**
- Keep at least one copy somewhere that a fire, theft or server failure cannot reach.
- Staff who handle backups should be the same few trusted administrators.
