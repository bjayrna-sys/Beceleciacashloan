# Becelecia Cashloan – Phase 1 core
Run: `cd backend && python3 server.py` then open http://localhost:8000 (Python 3.9+, no installs).
Demo logins (DEMO DATA): admin@demo.com / Demo@1234 (full), cashier@demo.com / Demo@1234 (payments only).
Settings (rates, limits, fees) live in the `settings` table; defaults in backend/engine.py.
Pages: / public website · /portal customers · /investor investors · /staff staff console.
