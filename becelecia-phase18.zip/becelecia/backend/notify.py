"""Notifications: in-app + queued email/SMS/WhatsApp, and configurable payment reminders.
Email/SMS/WhatsApp go to the outbox as PENDING_PROVIDER until a real sender is connected in _queue()."""
import json, re
from datetime import date
import db
M = lambda c: f"N${c/100:,.2f}"
CHANNELS = {"email": False, "sms": False, "whatsapp": False}; RULES = {"before": [10, 3], "on_due": True, "after": [3]}
def get(c, key, default):
    r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone(); return json.loads(r[0]) if r else default
def norm_phone(p):   # Namibian numbers -> international digits for wa.me links, e.g. 081 111 0001 -> 264811110001
    d = re.sub(r"\D", "", p or "")
    return d if d.startswith("264") else "264" + d[1:] if d.startswith("0") else "264" + d if len(d) == 9 else d
def _queue(c, channel, to, subject, body):   # connect a real provider here (e.g. SMTP, SMS gateway, WhatsApp Business API)
    c.execute("INSERT INTO outbox(channel,to_addr,subject,body,status) VALUES(?,?,?,?,'TO_SEND')", (channel, to, subject, body))
def user(c, uid, kind, title, body): c.execute("INSERT INTO notifications(user_id,kind,title,body) VALUES(?,?,?,?)", (uid, kind, title, body))
def customer(c, cid, kind, title, body):
    ch = get(c, "notify_channels", CHANNELS)
    for u in c.execute("SELECT id,email FROM users WHERE customer_id=?", (cid,)).fetchall():
        user(c, u["id"], kind, title, body)
        if ch.get("email"): _queue(c, "email", u["email"], title, body)
    ph = c.execute("SELECT phone FROM customers WHERE id=?", (cid,)).fetchone()
    for k in ("sms", "whatsapp"):
        if ph and norm_phone(ph[0]) and ch.get(k): _queue(c, k, norm_phone(ph[0]), title, body)
def staff(c, roles, kind, title, body):
    for u in c.execute(f"SELECT id FROM users WHERE active=1 AND role IN ({','.join('?' * len(roles))})", roles).fetchall(): user(c, u["id"], kind, title, body)

def run_reminders(c, s, loan_view, today=None):
    today = today or date.today(); rules = get(c, "reminder_rules", RULES); sent = 0
    for l in c.execute("SELECT * FROM loans").fetchall():
        v = loan_view(c, l, s)
        if v["status"] == "CLEARED": continue
        paid = c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE loan_id=? AND status='SUCCESS'", (l["id"],)).fetchone()[0]; cum = 0
        for i in c.execute("SELECT no,due,amount FROM schedule WHERE loan_id=? ORDER BY no", (l["id"],)).fetchall():
            cum += i["amount"]
            if cum <= paid: continue                       # instalment already covered by payments
            d = (date.fromisoformat(i["due"]) - today).days
            rule = f"before{d}" if d > 0 and d in rules["before"] else "due" if d == 0 and rules["on_due"] else f"after{-d}" if d < 0 and -d in rules["after"] else None
            if not rule or c.execute("INSERT OR IGNORE INTO reminder_log(loan_id,inst_no,rule) VALUES(?,?,?)", (l["id"], i["no"], rule)).rowcount == 0: continue
            owing = M(v["outstanding"]["total"]); sent += 1
            if d > 0: customer(c, l["customer_id"], "reminder", "Payment due soon", f"Instalment of {M(i['amount'])} on loan {l['no']} is due in {d} day(s) ({i['due']}). Outstanding: {owing}.")
            elif d == 0: customer(c, l["customer_id"], "reminder", "Payment due today", f"Instalment of {M(i['amount'])} on loan {l['no']} is due today. Outstanding: {owing}.")
            else:
                customer(c, l["customer_id"], "overdue", "Payment overdue", f"Instalment of {M(i['amount'])} on loan {l['no']} is {-d} day(s) overdue. Outstanding: {owing}. Penalties may apply after the {s['grace_days']}-day grace period.")
                staff(c, ("admin", "loan_officer"), "overdue", "Overdue loan", f"{l['no']} is {-d} day(s) overdue. Outstanding {owing}.")
    return sent

def ints(v, name):
    try: x = sorted({int(p) for p in re.split(r"[,\s]+", str(v).strip()) if p}, reverse=True)
    except ValueError: raise ValueError(f"{name}: enter whole numbers separated by commas")
    if len(x) > 6 or any(not 1 <= n <= 60 for n in x): raise ValueError(f"{name}: use up to 6 values between 1 and 60")
    return x

def route(h, c, m, path, b, s, loan_view):
    if not path.startswith("/api/notifications"): return False
    u = h.user()
    if not u: raise PermissionError("Please log in")
    if path == "/api/notifications" and m == "GET":
        rows = [dict(r) for r in c.execute("SELECT id,kind,title,body,read,created FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50", (u["id"],))]
        h.send(200, dict(rows=rows, unread=c.execute("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read=0", (u["id"],)).fetchone()[0])); return True
    if path == "/api/notifications/read" and m == "POST":
        if b.get("all"): c.execute("UPDATE notifications SET read=1 WHERE user_id=?", (u["id"],))
        else: c.execute("UPDATE notifications SET read=1 WHERE user_id=? AND id=?", (u["id"], b.get("id")))
        h.send(200, dict(ok=True)); return True
    if path == "/api/notifications/outbox" and m == "GET":
        h.need("loans:read"); h.send(200, [dict(r) for r in c.execute("SELECT id,channel,to_addr,subject,body,attempts,error FROM outbox WHERE status='TO_SEND' ORDER BY id LIMIT 50")]); return True
    mm = re.fullmatch(r"/api/notifications/outbox/(\d+)/sent", path)
    if mm and m == "POST":
        u2 = h.need("loans:read"); c.execute("UPDATE outbox SET status='SENT' WHERE id=?", (mm[1],)); db.audit(c, u2["id"], "MESSAGE_SENT", mm[1]); h.send(200, dict(ok=True)); return True
    h.need("settings")
    if path == "/api/notifications/settings":
        if m == "POST":
            r = dict(before=ints(b.get("before", ""), "Before due"), on_due=bool(b.get("on_due")), after=ints(b.get("after", ""), "Overdue"))
            ch = {k: bool((b.get("channels") or {}).get(k)) for k in CHANNELS}
            c.execute("INSERT OR REPLACE INTO settings VALUES('reminder_rules',?)", (json.dumps(r),)); c.execute("INSERT OR REPLACE INTO settings VALUES('notify_channels',?)", (json.dumps(ch),))
            db.audit(c, u["id"], "NOTIFICATION_SETTINGS_CHANGED", "reminders", json.dumps(dict(rules=r, channels=ch)))
        h.send(200, dict(get(c, "reminder_rules", RULES), channels=get(c, "notify_channels", CHANNELS), outbox=[dict(r) for r in c.execute("SELECT channel,to_addr,subject,status,created FROM outbox ORDER BY id DESC LIMIT 20")])); return True
    if path == "/api/notifications/run-reminders" and m == "POST":
        today = date.fromisoformat(b["today"]) if b.get("today") else None     # optional date override for testing
        n = run_reminders(c, s, loan_view, today); db.audit(c, u["id"], "REMINDERS_RUN", str(today or date.today()), f"{n} sent"); h.send(200, dict(sent=n)); return True
    return False
