"""Finance: expenses, cash & bank balances, loan disbursement tracking, cash transactions, bank reconciliation.
Balances = opening balance + manual cash entries + payments received - expenses. Cash payments/expenses hit CASH, everything else BANK.
TEST-mode gateway payments are fake money and never count. Income (profit) = interest + penalties collected - expenses; fees/levies are shown separately."""
import base64, json, os, re, secrets
from datetime import date
from urllib.parse import urlparse, parse_qs
import db, notify, payments as pay
from portal import MAGIC, UP
M = lambda c: f"N${c/100:,.2f}"
def get(c, k, d=0):
    r = c.execute("SELECT value FROM settings WHERE key=?", (k,)).fetchone(); return json.loads(r[0]) if r else d
def money(v):
    try: x = round(float(v) * 100)
    except (TypeError, ValueError): raise ValueError("Invalid amount")
    if x <= 0: raise ValueError("Amount must be greater than zero")
    return x
def day(v):
    try: return date.fromisoformat(str(v)).isoformat()
    except ValueError: raise ValueError("Enter a valid date (YYYY-MM-DD)")
REAL = "NOT (p.method='Online gateway' AND p.mode='test')"
def balances(c):
    out = {}
    for acct, cash in (("CASH", True), ("BANK", False)):
        cond = "p.method='Cash'" if cash else "p.method!='Cash'"
        pin = c.execute(f"SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.status='SUCCESS' AND {REAL} AND {cond}").fetchone()[0]
        ex = c.execute(f"SELECT COALESCE(SUM(amount),0) FROM expenses p WHERE {'method=' if cash else 'method!='}'Cash'").fetchone()[0]
        tx = c.execute("SELECT COALESCE(SUM(CASE kind WHEN 'IN' THEN amount ELSE -amount END),0) FROM cash_transactions WHERE account=?", (acct,)).fetchone()[0]
        out[acct] = get(c, "opening_" + acct.lower()) + pin + tx - ex
    return out
def collected(c, a, b):
    r = {x["bucket"]: x["t"] for x in c.execute(f"SELECT al.bucket,SUM(al.amount) t FROM allocations al JOIN payments p ON p.id=al.payment_id WHERE p.status='SUCCESS' AND {REAL} AND date(p.created) BETWEEN ? AND ? GROUP BY al.bucket", (a, b))}
    total = c.execute(f"SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.status='SUCCESS' AND {REAL} AND date(p.created) BETWEEN ? AND ?", (a, b)).fetchone()[0]
    return r, total
def summary(c, s, loan_view, a, b):
    from investors import account
    bal = balances(c); r, total = collected(c, a, b)
    exp = c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date BETWEEN ? AND ?", (a, b)).fetchone()[0]
    dis = c.execute("SELECT COALESCE(SUM(amount),0) FROM cash_transactions WHERE category='Loan disbursement' AND date BETWEEN ? AND ?", (a, b)).fetchone()[0]
    views = [loan_view(c, l, s) for l in c.execute("SELECT * FROM loans")]; live = [v for v in views if v["status"] != "CLEARED"]
    inv = [account(c, i["id"], s, loan_view) for i in c.execute("SELECT id FROM investors")]
    inc = r.get("interest", 0) + r.get("penalty", 0)
    return [("Cash balance", M(bal["CASH"])), ("Bank balance", M(bal["BANK"])), ("Money disbursed (period)", M(dis)), ("Money collected (period)", M(total)),
        ("Interest collected", M(r.get("interest", 0))), ("Penalties collected", M(r.get("penalty", 0))), ("Fees & levies collected", M(r.get("fees", 0))), ("Expenses (period)", M(exp)),
        ("Profit (interest + penalties - expenses)", M(inc - exp)), ("Outstanding loans", len(live)), ("Total receivables", M(sum(v["outstanding"]["total"] for v in live))),
        ("Investor capital held", M(sum(i["capital"] for i in inv))), ("Investor earnings accrued", M(sum(i["earnings"] for i in inv)))]
def qs(h): return {k: v[0] for k, v in parse_qs(urlparse(h.path).query).items()}

def route(h, c, m, path, b, s, loan_view):
    if not (path.startswith("/api/finance") or path.startswith("/api/expense")): return False
    u = h.need("finance")
    if path == "/api/finance/summary":
        q = qs(h); a, e = day(q.get("from", date.today().replace(day=1))), day(q.get("to", date.today())); h.send(200, dict(from_=a, to=e, summary=summary(c, s, loan_view, a, e))); return True
    if path == "/api/finance/awaiting":
        h.send(200, [dict(id=l["id"], no=l["no"], principal=l["principal"], customer=l["name"]) for l in c.execute("SELECT l.id,l.no,l.principal,cu.name FROM loans l JOIN customers cu ON cu.id=l.customer_id WHERE NOT EXISTS (SELECT 1 FROM cash_transactions t WHERE t.loan_id=l.id AND t.category='Loan disbursement') ORDER BY l.id")]); return True
    if path == "/api/finance/disburse" and m == "POST":
        l = c.execute("SELECT * FROM loans WHERE no=?", (b.get("loan_no"),)).fetchone(); acct = {"cash": "CASH", "bank": "BANK"}.get(b.get("account"))
        if not l or not acct: raise ValueError("Choose a loan and Cash or Bank")
        if c.execute("SELECT 1 FROM cash_transactions WHERE loan_id=? AND category='Loan disbursement'", (l["id"],)).fetchone(): raise ValueError("This loan has already been disbursed")
        c.execute("INSERT INTO cash_transactions(date,kind,account,amount,category,description,reference,loan_id,user_id) VALUES(?,?,?,?,?,?,?,?,?)", (date.today().isoformat(), "OUT", acct, l["principal"], "Loan disbursement", f"Disbursed loan {l['no']}", l["no"], l["id"], u["id"]))
        db.audit(c, u["id"], "LOAN_DISBURSED", l["no"], f"{M(l['principal'])} from {acct}"); notify.customer(c, l["customer_id"], "loan_disbursed", "Loan disbursed", f"Loan {l['no']} of {M(l['principal'])} has been disbursed."); h.send(200, dict(ok=True)); return True
    if path == "/api/finance/cash":
        if m == "GET": h.send(200, [dict(r) for r in c.execute("SELECT date,kind,account,amount,category,description,reference FROM cash_transactions ORDER BY id DESC LIMIT 30")]); return True
        if b.get("kind") not in ("IN", "OUT") or b.get("account") not in ("CASH", "BANK") or not str(b.get("category", "")).strip(): raise ValueError("Choose in/out, cash/bank and a category")
        c.execute("INSERT INTO cash_transactions(date,kind,account,amount,category,description,reference,user_id) VALUES(?,?,?,?,?,?,?,?)", (day(b.get("date") or date.today()), b["kind"], b["account"], money(b.get("amount")), str(b["category"])[:60], str(b.get("description", ""))[:200], str(b.get("reference", ""))[:60], u["id"]))
        db.audit(c, u["id"], "CASH_TRANSACTION", b["account"], f"{b['kind']} {b.get('amount')}"); h.send(200, dict(ok=True)); return True
    if path == "/api/finance/opening" and m == "POST":
        for k in ("cash", "bank"):
            if k in b: c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", ("opening_" + k, json.dumps(round(float(b[k]) * 100))))
        db.audit(c, u["id"], "OPENING_BALANCE_SET", "finance", json.dumps(b)); h.send(200, dict(ok=True)); return True
    if path == "/api/finance/reconcile":
        if m == "POST":
            sb = round(float(b.get("statement_balance")) * 100); sysb = balances(c)["BANK"]
            c.execute("INSERT INTO reconciliations(date,statement_balance,system_balance,difference,note,user_id) VALUES(?,?,?,?,?,?)", (day(b.get("date") or date.today()), sb, sysb, sb - sysb, str(b.get("note", ""))[:200], u["id"])); db.audit(c, u["id"], "BANK_RECONCILED", "bank", f"diff {M(sb - sysb)}")
        h.send(200, [dict(r) for r in c.execute("SELECT date,statement_balance,system_balance,difference,note FROM reconciliations ORDER BY id DESC LIMIT 10")]); return True
    if path == "/api/expense-categories":
        if m == "POST":
            n = str(b.get("name", "")).strip()[:40]
            if not n: raise ValueError("Category name is required")
            c.execute("INSERT OR IGNORE INTO expense_categories(name) VALUES(?)", (n,)); db.audit(c, u["id"], "EXPENSE_CATEGORY_ADDED", n)
        h.send(200, [dict(r) for r in c.execute("SELECT id,name FROM expense_categories ORDER BY name")]); return True
    if path == "/api/expenses" and m == "GET":
        q = qs(h); w, p = ["1=1"], []
        if q.get("from"): w.append("e.date>=?"); p.append(q["from"])
        if q.get("to"): w.append("e.date<=?"); p.append(q["to"])
        h.send(200, [dict(r) for r in c.execute(f"SELECT e.id,e.date,k.name category,e.payee,e.amount,e.method,e.reference,e.description,e.doc_name FROM expenses e JOIN expense_categories k ON k.id=e.category_id WHERE {' AND '.join(w)} ORDER BY e.date DESC,e.id DESC LIMIT 100", p)]); return True
    if path == "/api/expenses" and m == "POST":
        k = c.execute("SELECT id FROM expense_categories WHERE id=? OR name=?", (b.get("category_id"), b.get("category"))).fetchone()
        if not k: raise ValueError("Choose a valid expense category")
        method = b.get("method", "Cash")
        if method != "Cash" and method not in pay.get(c, "payment_methods", pay.DEFAULT_METHODS): raise ValueError("Payment method is not enabled")
        if not str(b.get("payee", "")).strip(): raise ValueError("Supplier / payee is required")
        stored = mime = name = None
        if b.get("doc"):
            try: raw = base64.b64decode(b["doc"], validate=True)
            except Exception: raise ValueError("Invalid document")
            mime = next((v for mg, v in MAGIC.items() if raw.startswith(mg)), None)
            if not mime or len(raw) > 5_000_000: raise ValueError("Documents must be JPG, PNG or PDF up to 5MB")
            os.makedirs(UP, exist_ok=True); stored = secrets.token_hex(16); open(os.path.join(UP, stored), "wb").write(raw); name = re.sub(r"[^\w.\-]", "_", str(b.get("doc_name", "document")))[:80]
        eid = c.execute("INSERT INTO expenses(date,category_id,payee,amount,description,method,reference,doc_stored,doc_mime,doc_name,user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (day(b.get("date") or date.today()), k[0], str(b["payee"]).strip()[:100], money(b.get("amount")), str(b.get("description", ""))[:200], method, str(b.get("reference", ""))[:60], stored, mime, name, u["id"])).lastrowid
        db.audit(c, u["id"], "EXPENSE_RECORDED", str(eid), f"{b.get('amount')} {b['payee']}"); h.send(200, dict(id=eid)); return True
    mm = re.fullmatch(r"/api/expenses/(\d+)/document", path)
    if mm:
        e = c.execute("SELECT * FROM expenses WHERE id=?", (mm[1],)).fetchone()
        if not e or not e["doc_stored"]: raise ValueError("No document attached")
        h.send(200, open(os.path.join(UP, e["doc_stored"]), "rb").read(), e["doc_mime"]); return True
    return False
