import html, json, os, re, secrets
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from datetime import date
import db, engine, portal, namfisa, documents, payments, settings_api, users_api, notify, investors, finance, reports, credit, public_api, mailer, otp, threading, time
SESS, FAILS = {}, {}
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")
PERM = {"admin": {"customers","loans","payments","reports","settings","investors","finance","blacklist","blacklist_admin"}, "cashier": {"customers:read","loans:read","payments"}, "customer": {"portal"}, "loan_officer": {"customers","loans","blacklist"}, "investor": {"investor"}, "accountant": {"finance","reports","customers:read","loans:read"}}

def loan_view(c, row, s):
    paid = {b: 0 for b in ("penalty","fees","interest","principal")}
    for a in c.execute("SELECT a.bucket,SUM(a.amount) t FROM allocations a JOIN payments p ON p.id=a.payment_id WHERE p.loan_id=? AND p.status='SUCCESS' GROUP BY a.bucket", (row["id"],)):
        if a["bucket"] in paid: paid[a["bucket"]] = a["t"]
    fees_total = row["fees"] + row["levy"]
    pi_out = (row["interest"] - paid["interest"]) + (row["principal"] - paid["principal"])
    pen = max(row["penalty_charged"], engine.penalty_due(pi_out, row["due_date"], s))
    out = dict(penalty=pen - paid["penalty"], fees=fees_total - paid["fees"], interest=row["interest"] - paid["interest"], principal=row["principal"] - paid["principal"])
    out["total"] = sum(out.values())
    over = max(0, (date.today() - date.fromisoformat(row["due_date"])).days)
    status = "CLEARED" if out["total"] <= 0 else ("OVERDUE" if over > 0 else "ACTIVE")
    return dict(dict(row), penalty_charged=pen, outstanding=out, days_overdue=over, status=status)

class H(BaseHTTPRequestHandler):
    sess, fails = SESS, FAILS
    def log_message(self, *a): pass
    def send(self, code, body, ctype="application/json", fn=None):
        data = body if isinstance(body, bytes) else (json.dumps(body) if ctype == "application/json" else body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("X-Content-Type-Options", "nosniff")
        if fn: self.send_header("Content-Disposition", f'attachment; filename="{fn}"')
        self.end_headers(); self.wfile.write(data)
    def user(self):
        t = self.headers.get("Authorization", "").replace("Bearer ", "")
        q = re.search(r"[?&]t=([^&]+)", self.path)
        if not t and q: t = q[1]
        return SESS.get(t)
    def handle_any(self, method):
        path = self.path.split("?")[0]
        try:
            if method == "GET" and not path.startswith("/api"):
                f = "logo.jpeg" if path == "/logo.jpeg" else ("portal.html" if path.startswith("/portal") else "investor.html" if path.startswith("/investor") else "index.html" if path.startswith("/staff") else "site.html")
                if path == "/auth.js": return self.send(200, open(os.path.join(WEB, "auth.js"), "rb").read(), "application/javascript")
                return self.send(200, open(os.path.join(WEB, f), "rb").read(), "image/jpeg" if f.endswith("jpeg") else "text/html")
            if int(self.headers.get("Content-Length", 0) or 0) > 8_000_000: raise ValueError("File is too large (max 5MB)")
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0)) or 0) or b"{}")
            c = db.conn()
            try: self.route(c, method, path, body); c.commit()
            except Exception: c.rollback(); raise
            finally: c.close()
        except ValueError as e: self.send(400, {"error": str(e)})
        except PermissionError as e: self.send(403, {"error": str(e)})
        except Exception: self.send(500, {"error": "Something went wrong. Please try again."})
    def do_GET(self): self.handle_any("GET")
    def do_POST(self): self.handle_any("POST")
    def need(self, perm):
        u = self.user()
        if not u: raise PermissionError("Please log in")
        p = PERM.get(u["role"], set())
        if perm not in p and perm.split(":")[0] not in p: raise PermissionError("Insufficient permissions")
        return u
    def route(self, c, m, path, b):
        s = db.settings(c)
        if path == "/api/auth/login":
            k = b.get("email", "")
            if FAILS.get(k, 0) >= 5: raise PermissionError("Account temporarily locked")
            r = c.execute("SELECT * FROM users WHERE email=? AND active=1", (k,)).fetchone()
            if not r or not db.check(b.get("password", ""), r["pw"]):
                FAILS[k] = FAILS.get(k, 0) + 1; db.audit(c, None, "LOGIN_FAILED", str(k)[:120]); c.commit(); raise PermissionError("Invalid email or password")
            if r["twofa"] or r["role"] in otp.required_roles(c): return self.send(200, dict(need_otp=True, challenge=otp.issue(c, r, "login", s, 10)))      # code is emailed; session is created only after verify-otp
            db.audit(c, r["id"], "LOGIN", k)
            FAILS[k] = 0; t = secrets.token_urlsafe(32); SESS[t] = dict(id=r["id"], role=r["role"], name=r["name"])
            return self.send(200, dict(token=t, role=r["role"], name=r["name"]))
        if path == "/api/customers":
            if m == "GET": self.need("customers:read"); return self.send(200, [dict(r) for r in c.execute("SELECT * FROM customers ORDER BY id DESC LIMIT 200")])
            u = self.need("customers")
            if not re.fullmatch(r"[0-9]{11}", str(b.get("id_number", ""))): raise ValueError("ID number must be 11 digits")
            if not b.get("name"): raise ValueError("Name is required")
            if c.execute("SELECT 1 FROM customers WHERE id_number=?", (b["id_number"],)).fetchone(): raise ValueError("ID number already exists")
            no = db.next_no(c, "customer", "CL")
            c.execute("INSERT INTO customers(no,name,id_number,phone,employer,salary_cents) VALUES(?,?,?,?,?,?)", (no, b["name"], b["id_number"], b.get("phone"), b.get("employer"), round(float(b.get("salary") or 0) * 100)))
            db.audit(c, u["id"], "CUSTOMER_CREATED", no); return self.send(200, dict(no=no))
        if path == "/api/loans" and m == "POST":
            u = self.need("loans")
            cu = c.execute("SELECT * FROM customers WHERE id=?", (b.get("customer_id"),)).fetchone()
            if not cu: raise ValueError("Customer not found")
            if cu["blacklisted"]: raise ValueError("Customer is blacklisted")
            q = engine.quote(round(float(b["amount"]) * 100), int(b["days"]), b["frequency"], s)   # server-side only
            no = db.next_no(c, "loan", "LN")
            cur = c.execute("INSERT INTO loans(no,customer_id,principal,interest,levy,fees,total,due_date,frequency,investor_share,stamp,bank) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (no, cu["id"], q["principal"], q["interest"], q["levy"], q["fees"], q["total"], q["due_date"], b["frequency"], q["investor_share"], q["stamp"], q["bank"]))
            for i in q["schedule"]: c.execute("INSERT INTO schedule(loan_id,no,due,amount) VALUES(?,?,?,?)", (cur.lastrowid, i["no"], i["due"], i["amount"]))
            investors.auto_allocate(c, cur.lastrowid, s, loan_view); db.audit(c, u["id"], "LOAN_CREATED", no, json.dumps(q["schedule"])); notify.customer(c, cu["id"], "loan_created", "Loan created", f"Loan {no}: total to repay {notify.M(q['total'])}, final due date {q['due_date']}."); return self.send(200, dict(no=no, **q))
        if path == "/api/loans" and m == "GET":
            self.need("loans:read"); return self.send(200, [dict(loan_view(c, r, s), customer=r["cname"]) for r in c.execute("SELECT l.*,c.name cname FROM loans l JOIN customers c ON c.id=l.customer_id ORDER BY l.id DESC LIMIT 200")])
        if otp.route(self, c, m, path, b, s, loan_view): return
        if mailer.route(self, c, m, path, b, s, loan_view): return
        if public_api.route(self, c, m, path, b, s, loan_view): return
        if credit.route(self, c, m, path, b, s, loan_view): return
        if finance.route(self, c, m, path, b, s, loan_view): return
        if reports.route(self, c, m, path, b, s, loan_view): return
        if investors.route(self, c, m, path, b, s, loan_view): return
        if notify.route(self, c, m, path, b, s, loan_view): return
        if users_api.route(self, c, m, path, b, s, loan_view): return
        if settings_api.route(self, c, m, path, b, s, loan_view): return
        if payments.route(self, c, m, path, b, s, loan_view): return
        if documents.route(self, c, m, path, b, s, loan_view): return
        if namfisa.route(self, c, m, path, b, s, loan_view): return
        if portal.route(self, c, m, path, b, s, loan_view): return
        self.send(404, {"error": "Not found"})

def mail_loop():
    while True:   # sends queued emails automatically when SMTP is set up
        try:
            c = db.conn(); mailer.deliver_pending(c, db.settings(c)); c.commit(); c.close()
        except Exception: pass
        time.sleep(30)

def reminder_loop():
    while True:   # checks hourly; each reminder is sent at most once
        try:
            c = db.conn(); notify.run_reminders(c, db.settings(c), loan_view); c.commit(); c.close()
        except Exception: pass
        time.sleep(3600)

if __name__ == "__main__":
    db.init(); threading.Thread(target=reminder_loop, daemon=True).start(); threading.Thread(target=mail_loop, daemon=True).start(); host, port = os.environ.get("HOST", "0.0.0.0"), int(os.environ.get("PORT", "8000")); print(f"Becelecia running on http://{host}:{port}"); ThreadingHTTPServer((host, port), H).serve_forever()
