"""Investor accounts, loan allocations and statements.
Business rule: an investor funds investor_pct (default 15%) of each loan's principal. Their money comes back as the loan's PRINCIPAL is repaid.
Interest, fees and penalties belong to Becelecia, except an optional configurable earnings % (investor_earning_pct, default 0).
Recoveries and earnings are derived from payment allocations, so they can never disagree with loan payments."""
import io, json, re
from urllib.parse import urlparse, parse_qs
import db
from documents import company_lines, LOGO, E, M, page
from users_api import strong

def paid(c, loan_id, bucket):
    return c.execute("SELECT COALESCE(SUM(a.amount),0) FROM allocations a JOIN payments p ON p.id=a.payment_id WHERE p.loan_id=? AND p.status='SUCCESS' AND a.bucket=?", (loan_id, bucket)).fetchone()[0]

def account(c, iid, s, loan_view):
    cap = c.execute("SELECT COALESCE(SUM(CASE kind WHEN 'DEPOSIT' THEN amount ELSE -amount END),0) FROM investor_tx WHERE investor_id=?", (iid,)).fetchone()[0]
    pct = s.get("investor_earning_pct", 0); loans = []; tot = dict(allocated=0, recovered=0, earnings=0)
    for a in c.execute("SELECT ia.amount,l.* FROM investor_alloc ia JOIN loans l ON l.id=ia.loan_id WHERE ia.investor_id=? ORDER BY l.id", (iid,)).fetchall():
        frac = a["amount"] / a["principal"]; rec = round(paid(c, a["id"], "principal") * frac); ern = round(paid(c, a["id"], "interest") * frac * pct)
        loans.append(dict(no=a["no"], date=a["created"][:10], principal=a["principal"], share=a["amount"], recovered=rec, outstanding=a["amount"] - rec, earnings=ern, status=loan_view(c, a, s)["status"]))
        tot["allocated"] += a["amount"]; tot["recovered"] += rec; tot["earnings"] += ern
    out = tot["allocated"] - tot["recovered"]
    return dict(capital=cap, outstanding=out, available=cap - out, loans=loans, **tot)

def ledger(c, iid, s):
    rows = [(r["created"], 0, r["kind"], r["note"] or r["kind"].title(), r["amount"] if r["kind"] == "DEPOSIT" else -r["amount"], 0) for r in c.execute("SELECT * FROM investor_tx WHERE investor_id=?", (iid,))]
    pct = s.get("investor_earning_pct", 0)
    for a in c.execute("SELECT ia.amount,ia.created ac,l.id,l.no,l.principal FROM investor_alloc ia JOIN loans l ON l.id=ia.loan_id WHERE ia.investor_id=?", (iid,)).fetchall():
        rows.append((a["ac"], 1, "ALLOCATION", f"Allocated to loan {a['no']}", -a["amount"], 0)); frac = a["amount"] / a["principal"]; cp = ci = pr = pe = 0
        for p in c.execute("SELECT p.created,SUM(CASE al.bucket WHEN 'principal' THEN al.amount ELSE 0 END) pr,SUM(CASE al.bucket WHEN 'interest' THEN al.amount ELSE 0 END) it FROM payments p JOIN allocations al ON al.payment_id=p.id WHERE p.loan_id=? AND p.status='SUCCESS' GROUP BY p.id ORDER BY p.id", (a["id"],)):
            cp += p["pr"]; ci += p["it"]; r, e = round(cp * frac), round(ci * frac * pct)
            if r > pr: rows.append((p["created"], 2, "RECOVERY", f"Principal recovered on {a['no']}", r - pr, 0)); pr = r
            if e > pe: rows.append((p["created"], 3, "EARNING", f"Earnings on {a['no']}", 0, e - pe)); pe = e
    rows.sort(key=lambda r: (r[0], r[1])); bal = 0; out = []
    for w, _, k, d, eff, ern in rows: bal += eff; out.append(dict(date=w[:10], type=k, desc=d, amount=eff, earned=ern, balance=bal))
    return out

def auto_allocate(c, loan_id, s, loan_view):
    l = c.execute("SELECT * FROM loans WHERE id=?", (loan_id,)).fetchone()
    need = l["investor_share"] - c.execute("SELECT COALESCE(SUM(amount),0) FROM investor_alloc WHERE loan_id=?", (loan_id,)).fetchone()[0]
    for av, iid in sorted(((account(c, i["id"], s, loan_view)["available"], i["id"]) for i in c.execute("SELECT id FROM investors WHERE active=1")), reverse=True):
        take = min(av, need)
        if take > 0: c.execute("INSERT INTO investor_alloc(investor_id,loan_id,amount) VALUES(?,?,?) ON CONFLICT(investor_id,loan_id) DO UPDATE SET amount=amount+excluded.amount", (iid, loan_id, take)); need -= take
        if need <= 0: break

def unfunded(c):
    rows = c.execute("SELECT l.id,l.investor_share-COALESCE((SELECT SUM(amount) FROM investor_alloc WHERE loan_id=l.id),0) gap FROM loans l").fetchall()
    return [(r["id"], r["gap"]) for r in rows if r["gap"] > 0]

def render(c, inv, s, loan_view, pdf, by, tk):
    a = account(c, inv["id"], s, loan_view); led = ledger(c, inv["id"], s); assert not led or led[-1]["balance"] == a["available"], "investor ledger does not reconcile"
    summ = [("Capital invested", a["capital"]), ("Allocated to loans", a["allocated"]), ("Recovered", a["recovered"]), ("Outstanding with borrowers", a["outstanding"]), ("Available to lend", a["available"]), ("Earnings", a["earnings"])]
    biz = company_lines(s)
    if not pdf:
        t = lambda h, rows: "<div style='overflow:auto'><table width=100%><tr>" + "".join(f"<th>{x}" for x in h) + "</tr>" + "".join("<tr>" + "".join(f"<td>{x}" for x in r) + "</tr>" for r in rows) + "</table></div>"
        body = f"<h3>Investor statement – {E(inv['name'])}</h3>" + t(["Summary", ""], [(k, M(v)) for k, v in summ]) + "<h4>Loans</h4>" + t(["Loan", "Date", "Principal", "Investor share", "Recovered", "Outstanding", "Status"], [(l["no"], l["date"], M(l["principal"]), M(l["share"]), M(l["recovered"]), M(l["outstanding"]), l["status"]) for l in a["loans"]]) + "<h4>Transactions</h4>" + t(["Date", "Description", "Amount", "Earned", "Balance"], [(r["date"], E(r["desc"]), M(r["amount"]), M(r["earned"]) if r["earned"] else "", M(r["balance"])) for r in led])
        return page("<br>".join(map(E, biz)), body, f"?format=pdf{tk}"), "text/html"
    from reportlab.lib.pagesizes import A4; from reportlab.platypus import SimpleDocTemplate, Table, Paragraph, Spacer, Image
    from reportlab.lib.styles import getSampleStyleSheet; from reportlab.lib import colors; from datetime import datetime
    st = getSampleStyleSheet(); b = io.BytesIO(); gr = [("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("FONTSIZE", (0, 0), (-1, -1), 8)]; hd = [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F4AA8")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
    foot = lambda cv, d: (cv.setFont("Helvetica", 8), cv.drawRightString(555, 20, f"Page {d.page}"), cv.drawString(40, 20, f"Generated {datetime.now():%Y-%m-%d %H:%M} by {by}"))
    el = [Image(LOGO, 170, 70, kind="proportional"), Paragraph("<br/>".join(map(E, biz)), st["Normal"]), Paragraph(f"Investor statement – {E(inv['name'])}", st["Title"]), Table([[k, M(v)] for k, v in summ], colWidths=[200, 100], style=gr), Spacer(1, 8), Paragraph("Loans", st["Heading3"]),
          Table([["Loan", "Date", "Principal", "Share", "Recovered", "Outstanding", "Status"]] + [[l["no"], l["date"], M(l["principal"]), M(l["share"]), M(l["recovered"]), M(l["outstanding"]), l["status"]] for l in a["loans"]], style=gr + hd, repeatRows=1), Spacer(1, 8), Paragraph("Transactions", st["Heading3"]),
          Table([["Date", "Description", "Amount", "Earned", "Balance"]] + [[r["date"], r["desc"], M(r["amount"]), M(r["earned"]) if r["earned"] else "", M(r["balance"])] for r in led], colWidths=[60, 230, 70, 60, 80], style=gr + hd, repeatRows=1)]
    SimpleDocTemplate(b, pagesize=A4, leftMargin=40, rightMargin=40).build(el, onFirstPage=foot, onLaterPages=foot); return b.getvalue(), "application/pdf"

def route(h, c, m, path, b, s, loan_view):
    if not (path.startswith("/api/investor")): return False
    q = h.path; pdf = "format=pdf" in q; tk = re.search(r"[?&]t=([^&]+)", q); tk = f"&t={tk[1]}" if tk else ""
    if path in ("/api/investor/me", "/api/investor/statement"):
        u = h.need("investor"); inv = c.execute("SELECT * FROM investors WHERE user_id=?", (u["id"],)).fetchone()
        if not inv: raise PermissionError("Insufficient permissions")
        if path.endswith("me"):
            a = account(c, inv["id"], s, loan_view); h.send(200, dict(name=inv["name"], summary={k: v for k, v in a.items() if k != "loans"}, loans=a["loans"], ledger=ledger(c, inv["id"], s))); return True
        db.audit(c, u["id"], "INVESTOR_STATEMENT", inv["name"]); body, ct = render(c, inv, s, loan_view, pdf, u["name"], tk); h.send(200, body, ct, "investor_statement.pdf" if pdf else None); return True
    u = h.need("investors")
    if path == "/api/investors" and m == "GET":
        gaps = unfunded(c); out = []
        for i in c.execute("SELECT * FROM investors ORDER BY id"):
            a = account(c, i["id"], s, loan_view); out.append(dict(id=i["id"], name=i["name"], active=i["active"], **{k: v for k, v in a.items() if k != "loans"}))
        h.send(200, dict(investors=out, unfunded=dict(count=len(gaps), amount=sum(g for _, g in gaps)))); return True
    if path == "/api/investors" and m == "POST":
        email = str(b.get("email", "")).strip().lower()
        if not str(b.get("name", "")).strip(): raise ValueError("Name is required")
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email): raise ValueError("Enter a valid email address")
        strong(b.get("password"))
        if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone(): raise ValueError("Email already registered")
        uid = c.execute("INSERT INTO users(email,name,role,pw) VALUES(?,?,'investor',?)", (email, b["name"].strip()[:100], db.hpw(b["password"]))).lastrowid
        iid = c.execute("INSERT INTO investors(user_id,name,email,phone) VALUES(?,?,?,?)", (uid, b["name"].strip()[:100], email, b.get("phone"))).lastrowid
        db.audit(c, u["id"], "INVESTOR_CREATED", email); h.send(200, dict(id=iid)); return True
    mm = re.fullmatch(r"/api/investors/(\d+)/(transaction|statement)", path)
    if mm:
        inv = c.execute("SELECT * FROM investors WHERE id=?", (mm[1],)).fetchone()
        if not inv: raise ValueError("Investor not found")
        if mm[2] == "statement":
            db.audit(c, u["id"], "INVESTOR_STATEMENT", inv["name"]); body, ct = render(c, inv, s, loan_view, pdf, u["name"], tk); h.send(200, body, ct, f"investor_{inv['id']}.pdf" if pdf else None); return True
        kind = {"deposit": "DEPOSIT", "withdrawal": "WITHDRAWAL"}.get(b.get("kind"))
        try: amt = round(float(b.get("amount")) * 100)
        except (TypeError, ValueError): raise ValueError("Invalid amount")
        if not kind or amt <= 0: raise ValueError("Enter a valid transaction")
        av = account(c, inv["id"], s, loan_view)["available"]
        if kind == "WITHDRAWAL" and amt > av: raise ValueError(f"Withdrawal exceeds available funds of {M(av)}")
        c.execute("INSERT INTO investor_tx(investor_id,kind,amount,note,user_id) VALUES(?,?,?,?,?)", (inv["id"], kind, amt, str(b.get("note", ""))[:200], u["id"])); db.audit(c, u["id"], "INVESTOR_" + kind, inv["name"], M(amt))
        if kind == "DEPOSIT":
            for lid, _ in unfunded(c): auto_allocate(c, lid, s, loan_view)      # put new capital to work on unfunded loans, oldest first
        h.send(200, dict(ok=True)); return True
    return False
