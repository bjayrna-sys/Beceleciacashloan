"""Customer portal + loan application workflow."""
import base64, json, os, re, secrets
import db, engine, payments, notify, investors
UP = os.environ.get("UPLOAD_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "uploads"))   # outside web root
REQUIRED = ("id_copy", "selfie_id", "bank_statement", "payslip")
MAGIC = {b"\xff\xd8\xff": "image/jpeg", b"\x89PNG": "image/png", b"%PDF": "application/pdf"}

def score(c, cust, total, salary, expenses, other, s):
    """Indicative score only; final decision stays with staff."""
    if cust["blacklisted"]: return "BLACKLISTED"
    if c.execute("SELECT 1 FROM loans l WHERE customer_id=? AND status!='CLEARED'", (cust["id"],)).fetchone(): return "REVIEW REQUIRED"
    disp = salary - expenses - other
    return "QUALIFIED" if total <= disp else ("REVIEW REQUIRED" if total <= disp * 1.5 else "NOT QUALIFIED")

def route(h, c, m, path, b, s, loan_view):
    if path == "/api/portal/register":
        if not re.fullmatch(r"[0-9]{11}", str(b.get("id_number", ""))): raise ValueError("ID number must be 11 digits")
        if len(b.get("password", "")) < 8: raise ValueError("Password must be at least 8 characters")
        if not b.get("name") or not b.get("email"): raise ValueError("Name and email are required")
        if c.execute("SELECT 1 FROM customers WHERE id_number=?", (b["id_number"],)).fetchone(): raise ValueError("ID number already exists")
        if c.execute("SELECT 1 FROM users WHERE email=?", (b["email"],)).fetchone(): raise ValueError("Email already registered")
        no = db.next_no(c, "customer", "CL")
        cid = c.execute("INSERT INTO customers(no,name,id_number,phone) VALUES(?,?,?,?)", (no, b["name"], b["id_number"], b.get("phone"))).lastrowid
        c.execute("INSERT INTO users(email,name,role,pw,customer_id) VALUES(?,?,?,?,?)", (b["email"], b["name"], "customer", db.hpw(b["password"]), cid))
        db.audit(c, None, "CUSTOMER_REGISTERED", no); notify.staff(c, ("admin", "loan_officer"), "new_customer", "New customer", f"{b['name']} ({no}) registered on the portal"); h.send(200, dict(no=no)); return True
    if path.startswith("/api/portal/"):
        u = h.need("portal"); cid = c.execute("SELECT customer_id FROM users WHERE id=?", (u["id"],)).fetchone()[0]
        cust = c.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone()
        if path == "/api/portal/me":
            h.send(200, dict(payment_mode=payments.get(c, "payment_mode", "test"), bank=payments.get(c, "bank_details", payments.DEFAULT_BANK), customer=dict(cust),
                applications=[dict(r) for r in c.execute("SELECT * FROM applications WHERE customer_id=? ORDER BY id DESC", (cid,))],
                documents=[r["kind"] for r in c.execute("SELECT kind FROM documents WHERE customer_id=?", (cid,))],
                loans=[dict(loan_view(c, r, s), schedule=[dict(x) for x in c.execute("SELECT no,due,amount FROM schedule WHERE loan_id=?", (r["id"],))], payments=[dict(x) for x in c.execute("SELECT r.no receipt,p.amount,date(p.created) d FROM payments p JOIN receipts r ON r.payment_id=p.id WHERE p.loan_id=? AND p.status='SUCCESS'", (r["id"],))], attempts=[dict(x) for x in c.execute("SELECT amount,status,date(created) d FROM payments WHERE loan_id=? AND status IN ('PENDING','FAILED') ORDER BY id DESC LIMIT 5", (r["id"],))]) for r in c.execute("SELECT * FROM loans WHERE customer_id=?", (cid,))])); return True
        if path == "/api/portal/documents":
            if b.get("kind") not in REQUIRED + ("other",): raise ValueError("Unknown document type")
            raw = base64.b64decode(b.get("data", ""), validate=True)
            if not 0 < len(raw) <= 5_000_000: raise ValueError("File is too large (max 5MB)")
            mime = next((v for k, v in MAGIC.items() if raw.startswith(k)), None)
            if not mime: raise ValueError("Only JPG, PNG or PDF files are allowed")
            os.makedirs(UP, exist_ok=True); name = secrets.token_hex(16)
            open(os.path.join(UP, name), "wb").write(raw)
            c.execute("INSERT INTO documents(customer_id,kind,filename,stored,mime) VALUES(?,?,?,?,?)", (cid, b["kind"], re.sub(r"[^\w.\-]", "_", b.get("filename", "file"))[:80], name, mime))
            db.audit(c, u["id"], "DOCUMENT_UPLOADED", cust["no"], b["kind"]); h.send(200, dict(ok=True)); return True
        if path == "/api/portal/applications":
            if cust["blacklisted"]: raise ValueError("We are unable to accept an online application at this time. Please contact Becelecia Cashloan.")
            have = {r["kind"] for r in c.execute("SELECT kind FROM documents WHERE customer_id=?", (cid,))}
            miss = [k for k in REQUIRED if k not in have]
            if miss: raise ValueError("Please upload: " + ", ".join(miss))
            if c.execute("SELECT 1 FROM applications WHERE customer_id=? AND status IN ('SUBMITTED','IN_REVIEW')", (cid,)).fetchone(): raise ValueError("You already have an application under review")
            amt = round(float(b["amount"]) * 100); days = int(b["days"])
            q = engine.quote(amt, days, b["frequency"], s)       # server validates limits and totals
            sal, exp, oth = (round(float(b.get(k) or 0) * 100) for k in ("salary", "expenses", "other_loans"))
            if sal <= 0: raise ValueError("Salary is required")
            sc = score(c, cust, q["total"], sal, exp, oth, s); no = db.next_no(c, "application", "AP")
            c.execute("INSERT INTO applications(no,customer_id,amount,days,frequency,employer,salary_cents,expenses_cents,other_loans_cents,total_due,score) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (no, cid, amt, days, b["frequency"], b.get("employer"), sal, exp, oth, q["total"], sc))
            c.execute("UPDATE customers SET employer=?, salary_cents=? WHERE id=?", (b.get("employer"), sal, cid))
            db.audit(c, u["id"], "APPLICATION_SUBMITTED", no, sc)
            notify.customer(c, cid, "application_received", "Application received", f"We received application {no} for {notify.M(amt)}. You will be notified once it has been assessed.")
            notify.staff(c, ("admin", "loan_officer"), "new_application", "New loan application", f"{no} from {cust['name']} for {notify.M(amt)} ({sc})")
            notify.staff(c, ("loan_officer",), "documents_review", "Documents requiring review", f"{cust['name']} uploaded documents for {no}"); h.send(200, dict(no=no, total_due=q["total"])); return True
    if path == "/api/applications" and m == "GET":
        h.need("loans"); h.send(200, [dict(r) for r in c.execute("SELECT a.*,c.name,c.no cno FROM applications a JOIN customers c ON c.id=a.customer_id ORDER BY a.id DESC LIMIT 200")]); return True
    mm = re.fullmatch(r"/api/applications/(AP\d+)", path)
    if mm and m == "GET":
        h.need("loans"); a = c.execute("SELECT * FROM applications WHERE no=?", (mm[1],)).fetchone()
        if not a: raise ValueError("Application not found")
        cid = a["customer_id"]; lv = [loan_view(c, r, s) for r in c.execute("SELECT * FROM loans WHERE customer_id=?", (cid,))]
        n_app, n_rej = c.execute("SELECT COUNT(*), SUM(status='REJECTED') FROM applications WHERE customer_id=?", (cid,)).fetchone()
        h.send(200, dict(application=dict(a), customer=dict(c.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone()),
            disposable=a["salary_cents"] - a["expenses_cents"] - a["other_loans_cents"],
            documents=[dict(r) for r in c.execute("SELECT id,kind,filename,verified FROM documents WHERE customer_id=? ORDER BY id", (cid,))],
            credit=dict(applications=n_app, rejected=n_rej or 0, outstanding=sum(1 for v in lv if v["status"] != "CLEARED"),
                loans=[dict(no=v["no"], principal=v["principal"], status=v["status"], days_overdue=v["days_overdue"], created=v["created"][:10]) for v in lv]))); return True
    mm = re.fullmatch(r"/api/documents/(\d+)/verify", path)
    if mm and m == "POST":
        u = h.need("loans"); d = c.execute("SELECT * FROM documents WHERE id=?", (mm[1],)).fetchone()
        if not d: raise ValueError("Document not found")
        c.execute("UPDATE documents SET verified=? WHERE id=?", (1 if b.get("verified") else 0, d["id"])); db.audit(c, u["id"], "DOCUMENT_VERIFIED" if b.get("verified") else "DOCUMENT_UNVERIFIED", str(d["id"]), d["kind"])
        h.send(200, dict(ok=True)); return True
    mm = re.fullmatch(r"/api/applications/(AP\d+)/decide", path)
    if mm:
        u = h.need("loans"); a = c.execute("SELECT * FROM applications WHERE no=?", (mm[1],)).fetchone()
        if not a or a["status"] not in ("SUBMITTED", "IN_REVIEW"): raise ValueError("Application not available for decision")
        if b.get("decision") == "reject":
            if not b.get("reason"): raise ValueError("A reason is required")
            c.execute("UPDATE applications SET status='REJECTED',reason=?,decided_by=? WHERE id=?", (b["reason"], u["id"], a["id"])); db.audit(c, u["id"], "APPLICATION_REJECTED", a["no"], b["reason"]); notify.customer(c, a["customer_id"], "application_rejected", "Application not approved", f"Application {a['no']} was not approved. Reason: {b['reason']}")
            h.send(200, dict(status="REJECTED")); return True
        if b.get("decision") != "approve": raise ValueError("Invalid decision")
        cu = c.execute("SELECT * FROM customers WHERE id=?", (a["customer_id"],)).fetchone()
        if cu["blacklisted"]: raise ValueError("Customer is blacklisted")
        ver = {r["kind"] for r in c.execute("SELECT kind FROM documents WHERE customer_id=? AND verified=1", (a["customer_id"],))}
        if [k for k in REQUIRED if k not in ver]: raise ValueError("Verify these documents first: " + ", ".join(k for k in REQUIRED if k not in ver))
        q = engine.quote(a["amount"], a["days"], a["frequency"], s); lno = db.next_no(c, "loan", "LN")
        cur = c.execute("INSERT INTO loans(no,customer_id,principal,interest,levy,fees,total,due_date,frequency,investor_share,stamp,bank) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (lno, cu["id"], q["principal"], q["interest"], q["levy"], q["fees"], q["total"], q["due_date"], a["frequency"], q["investor_share"], q["stamp"], q["bank"]))
        for i in q["schedule"]: c.execute("INSERT INTO schedule(loan_id,no,due,amount) VALUES(?,?,?,?)", (cur.lastrowid, i["no"], i["due"], i["amount"]))
        c.execute("UPDATE applications SET status='APPROVED',loan_no=?,decided_by=? WHERE id=?", (lno, u["id"], a["id"]))
        investors.auto_allocate(c, cur.lastrowid, s, loan_view); db.audit(c, u["id"], "APPLICATION_APPROVED", a["no"], lno); notify.customer(c, a["customer_id"], "application_approved", "Application approved", f"Application {a['no']} was approved. Loan {lno}: total to repay {notify.M(q['total'])}, final due date {q['due_date']}."); h.send(200, dict(status="APPROVED", loan_no=lno)); return True
    mm = re.fullmatch(r"/api/documents/(\d+)", path)
    if mm:   # staff, or the owning customer only
        u = h.user(); d = c.execute("SELECT * FROM documents WHERE id=?", (mm[1],)).fetchone()
        if not u or not d: raise PermissionError("Insufficient permissions")
        if u["role"] == "customer" and c.execute("SELECT customer_id FROM users WHERE id=?", (u["id"],)).fetchone()[0] != d["customer_id"]: raise PermissionError("Insufficient permissions")
        if u["role"] not in ("customer", "admin", "loan_officer"): raise PermissionError("Insufficient permissions")
        h.send(200, open(os.path.join(UP, d["stored"]), "rb").read(), d["mime"]); return True
    return False
