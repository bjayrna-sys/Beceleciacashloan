"""Receipts and customer statements (HTML for print + PDF). Amounts in cents."""
import html, io, os, re
from datetime import date, datetime
import db
LOGO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "logo.jpeg")
BIZ = ["Becelecia Cashloan CC", "Shop No. 16, Pelican Mall, Walvis Bay, Namibia", "+264 81 472 2735 · www.beceleciacashloan.com"]
M = lambda c: ("-" if c < 0 else "") + f"N${abs(c)/100:,.2f}"
E = lambda x: html.escape(str(x if x is not None else ""))

def authorise(h, c, cust_id):
    u = h.user()
    if not u: raise PermissionError("Please log in")
    if u["role"] == "customer":
        if c.execute("SELECT customer_id FROM users WHERE id=?", (u["id"],)).fetchone()[0] != cust_id: raise PermissionError("Insufficient permissions")
    else: h.need("loans:read")
    return u

def receipt_data(c, no):
    r = c.execute("SELECT r.no,p.*,l.no lno,l.customer_id,cu.name,cu.no cno,cu.id_number,u.name rby FROM receipts r JOIN payments p ON p.id=r.payment_id JOIN loans l ON l.id=p.loan_id JOIN customers cu ON cu.id=l.customer_id LEFT JOIN users u ON u.id=p.user_id WHERE r.no=?", (no,)).fetchone()
    if not r: raise ValueError("Receipt not found")
    al = [(a["bucket"], a["amount"]) for a in c.execute("SELECT bucket,amount FROM allocations WHERE payment_id=? ORDER BY id", (r["id"],))]
    return r, al

def statement_data(c, lno, s, loan_view):
    l = c.execute("SELECT * FROM loans WHERE no=?", (lno,)).fetchone()
    if not l: raise ValueError("Loan not found")
    v = loan_view(c, l, s); cu = c.execute("SELECT * FROM customers WHERE id=?", (l["customer_id"],)).fetchone()
    led = [(l["created"][:10], "Loan principal", l["principal"]), (l["created"][:10], "Interest", l["interest"]),
           (l["created"][:10], "NAMFISA levy, stamp duty & fees", l["fees"] + l["levy"])]
    pays = c.execute("SELECT p.created,p.amount,p.method,r.no FROM payments p JOIN receipts r ON r.payment_id=p.id WHERE p.loan_id=? AND p.status='SUCCESS' ORDER BY p.id", (l["id"],)).fetchall()
    led += [(p["created"][:10], f"Payment {p['no']} ({p['method']})", -p["amount"]) for p in pays]
    if v["penalty_charged"] > 0: led.append((date.today().isoformat(), "Penalty charged to date", v["penalty_charged"]))
    run, rows = 0, []
    for d, desc, amt in led: run += amt; rows.append((d, desc, amt, run))
    assert run == v["outstanding"]["total"], "statement does not reconcile"
    return l, v, cu, rows

def company_lines(s):
    c = s.get("company", {}); return [c.get("name", BIZ[0]), c.get("address", BIZ[1]), f'{c.get("phone", "+264 81 472 2735")} · {c.get("website", "www.beceleciacashloan.com")}']

def pdf_receipt(r, al, bal, biz):
    from reportlab.lib.pagesizes import A5; from reportlab.platypus import SimpleDocTemplate, Table, Paragraph, Spacer, Image
    from reportlab.lib.styles import getSampleStyleSheet; from reportlab.lib import colors
    st = getSampleStyleSheet(); b = io.BytesIO(); blue = colors.HexColor("#1F4AA8")
    gr = [("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("FONTSIZE", (0, 0), (-1, -1), 9)]
    el = [Image(LOGO, 170, 70, kind="proportional"), Paragraph("<br/>".join(map(E, biz)), st["Normal"]), Spacer(1, 8), Paragraph(f"<b>RECEIPT {r['no']}</b>", st["Heading2"]),
      Table([["Date", r["created"][:16]], ["Customer", r["name"]], ["Customer no / ID", f"{r['cno']} / ******{r['id_number'][-4:]}"], ["Loan no", r["lno"]], ["Payment method", r["method"]],
             ["Reference", r["reference"]], ["Amount received", M(r["amount"])]], colWidths=[110, 230], style=gr), Spacer(1, 6), Paragraph("<b>Allocation</b>", st["Normal"]),
      Table([[k.title(), M(a)] for k, a in al] or [["-", "-"]], colWidths=[110, 230], style=gr), Spacer(1, 6),
      Table([["Remaining balance", M(bal)], ["Received by", r["rby"] or ""]], colWidths=[110, 230], style=gr + [("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#EAF0FB"))]), Spacer(1, 26),
      Paragraph("Authorised signature: ______________________", st["Normal"])]
    SimpleDocTemplate(b, pagesize=A5, leftMargin=30, rightMargin=30, topMargin=24).build(el); return b.getvalue()

def pdf_statement(l, v, cu, rows, by, biz):
    from reportlab.lib.pagesizes import A4; from reportlab.platypus import SimpleDocTemplate, Table, Paragraph, Spacer, Image
    from reportlab.lib.styles import getSampleStyleSheet; from reportlab.lib import colors
    st = getSampleStyleSheet(); b = io.BytesIO(); blue = colors.HexColor("#1F4AA8"); o = v["outstanding"]
    gr = [("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("FONTSIZE", (0, 0), (-1, -1), 8.5)]
    paid = sum(-a for _, _, a, _ in rows if a < 0)
    def foot(cv, d): cv.setFont("Helvetica", 8); cv.drawRightString(555, 20, f"Page {d.page}"); cv.drawString(40, 20, f"Generated {datetime.now():%Y-%m-%d %H:%M} by {by}")
    el = [Image(LOGO, 170, 70, kind="proportional"), Paragraph("<br/>".join(map(E, biz)), st["Normal"]), Paragraph(f"Loan statement – {l['no']}", st["Title"]),
      Table([["Customer", cu["name"], "Customer no", cu["no"]], ["Phone", cu["phone"] or "", "Loan status", v["status"]], ["Original amount", M(l["principal"]), "Due date", l["due_date"]],
             ["Interest", M(l["interest"]), "Fees & levies", M(l["fees"] + l["levy"])], ["Penalties", M(v["penalty_charged"]), "Total paid", M(paid)],
             ["Outstanding", M(o["total"]), "Frequency", l["frequency"]]], colWidths=[85, 150, 85, 150], style=gr), Spacer(1, 10),
      Table([["Date", "Description", "Amount", "Balance"]] + [[d, desc, M(a), M(rb)] for d, desc, a, rb in rows], colWidths=[65, 250, 80, 80], repeatRows=1,
            style=gr + [("BACKGROUND", (0, 0), (-1, 0), blue), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("ALIGN", (2, 0), (-1, -1), "RIGHT")])]
    SimpleDocTemplate(b, pagesize=A4, leftMargin=40, rightMargin=40).build(el, onFirstPage=foot, onLaterPages=foot); return b.getvalue()

PAGE = "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><body style='font-family:system-ui;max-width:720px;margin:auto;padding:12px'><style>td,th{padding:5px;border-bottom:1px solid #ddd;text-align:left}@media print{.np{display:none}}</style><img src='/logo.jpeg' width=200><p>@@biz@@</p>@@body@@<p class=np><button onclick=print()>Print</button> <a href='@@pdf@@'>Download PDF</a></p></body>"

def page(biz, body, pdf): return PAGE.replace("@@biz@@", biz).replace("@@body@@", body).replace("@@pdf@@", html.escape(pdf))

def route(h, c, m, path, b, s, loan_view):
    biz = company_lines(s); q = re.search(r"format=(\w+)", h.path); pdf = bool(q and q[1] == "pdf"); tk = re.search(r"[?&]t=([^&]+)", h.path); tk = f"&t={tk[1]}" if tk else ""
    mm = re.fullmatch(r"/api/receipts/(R\d+)", path)
    if mm and m == "GET":
        r, al = receipt_data(c, mm[1]); u = authorise(h, c, r["customer_id"])
        bal = r["balance_after"] if r["balance_after"] is not None else 0
        if pdf: h.send(200, pdf_receipt(r, al, bal, biz), "application/pdf", mm[1] + ".pdf"); return True
        body = f"<h3>Receipt {E(r['no'])}</h3><p>{E(r['name'])} ({E(r['cno'])})<br>Loan {E(r['lno'])}<br>{E(r['created'])} · {E(r['method'])}<br>Ref {E(r['reference'])}<br>Received by {E(r['rby'])}</p><table width=100%>" + "".join(f"<tr><td>{k.title()}<td>{M(a)}</tr>" for k, a in al) + f"<tr><th>Total received<th>{M(r['amount'])}</tr><tr><td>Remaining balance<td>{M(bal)}</tr></table>"
        h.send(200, page(biz="<br>".join(map(E, biz)), body=body, pdf=f"/api/receipts/{mm[1]}?format=pdf{tk}"), "text/html"); return True
    mm = re.fullmatch(r"/api/loans/(LN\d+)/statement", path)
    if mm and m == "GET":
        l, v, cu, rows = statement_data(c, mm[1], s, loan_view); u = authorise(h, c, l["customer_id"])
        db.audit(c, u["id"], "STATEMENT_GENERATED", l["no"], "pdf" if pdf else "html")
        if pdf: h.send(200, pdf_statement(l, v, cu, rows, u["name"], biz), "application/pdf", f"statement_{l['no']}.pdf"); return True
        o = v["outstanding"]
        body = f"<h3>Loan statement {E(l['no'])}</h3><p>{E(cu['name'])} ({E(cu['no'])}) · Status <b>{v['status']}</b><br>Original amount {M(l['principal'])} · Interest {M(l['interest'])} · Fees &amp; levies {M(l['fees']+l['levy'])} · Penalties {M(v['penalty_charged'])}<br>Due {E(l['due_date'])} · <b>Outstanding {M(o['total'])}</b></p><div style='overflow:auto'><table width=100%><tr><th>Date<th>Description<th>Amount<th>Balance</tr>" + "".join(f"<tr><td>{d}<td>{E(desc)}<td>{M(a)}<td>{M(rb)}</tr>" for d, desc, a, rb in rows) + "</table></div>"
        h.send(200, page(biz="<br>".join(map(E, biz)), body=body, pdf=f"/api/loans/{l['no']}/statement?format=pdf{tk}"), "text/html"); return True
    return False
