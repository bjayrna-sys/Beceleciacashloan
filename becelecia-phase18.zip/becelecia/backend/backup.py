"""Consistent backup of the database + uploaded documents. Safe to run while the server is running.
Usage: python3 backup.py [--out DIR] [--keep N]      Optional encryption: set BACKUP_PASSPHRASE_FILE (needs gpg installed)."""
import argparse, glob, os, sqlite3, subprocess, sys, tarfile, tempfile
from datetime import datetime
ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("DB_PATH", os.path.join(ROOT, "..", "database", "becelecia.db")); UP = os.environ.get("UPLOAD_DIR", os.path.join(ROOT, "..", "uploads"))

def make(out, keep=30, prefix="becelecia-backup"):
    os.makedirs(out, exist_ok=True); os.chmod(out, 0o700); ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    with tempfile.TemporaryDirectory() as tmp:
        snap = os.path.join(tmp, "becelecia.db"); src, dst = sqlite3.connect(DB), sqlite3.connect(snap)
        src.backup(dst); ok = dst.execute("PRAGMA integrity_check").fetchone()[0]; src.close(); dst.close()      # online-safe snapshot
        if ok != "ok": sys.exit("Database integrity check failed: " + ok)
        path = os.path.join(out, f"{prefix}-{ts}.tar.gz")
        with tarfile.open(path, "w:gz") as t:
            t.add(snap, "becelecia.db")
            if os.path.isdir(UP): t.add(UP, "uploads")
    pf = os.environ.get("BACKUP_PASSPHRASE_FILE")
    if pf:
        subprocess.run(["gpg", "--batch", "--yes", "--pinentry-mode", "loopback", "--passphrase-file", pf, "-c", path], check=True); os.remove(path); path += ".gpg"
    os.chmod(path, 0o600)
    if prefix == "becelecia-backup":
        for old in sorted(glob.glob(os.path.join(out, "becelecia-backup-*")), reverse=True)[keep:]: os.remove(old)
    return path

if __name__ == "__main__":
    a = argparse.ArgumentParser(); a.add_argument("--out", default=os.environ.get("BACKUP_DIR", os.path.join(ROOT, "..", "backups"))); a.add_argument("--keep", type=int, default=30); x = a.parse_args()
    p = make(x.out, x.keep); print(f"Backup written: {p} ({os.path.getsize(p) // 1024} KB)")
