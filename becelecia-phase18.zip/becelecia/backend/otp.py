"""Emailed one-time codes: password reset, optional 2-step login. Codes are 6 digits, stored hashed, expire, allow 5 tries, and are limited to 5 requests per hour per user.
Security emails go straight through SMTP (never through the staff 'Messages to send' list, so staff can never see a customer's code)."""
import hashlib, json, secrets
import db, mailer
from users_api import strong
_h = lambda i, code: hashlib.sha256(f"{i}:{code}".encode()).hexdigest()

STAFF = ("admin", "loan_officer", "cashier", "accountant")
def required_roles(c):
    r = c.execute("SELECT value FROM settings WHERE key='require_2fa'").fetchone()
    return {"admin": ("admin",), "staff": STAFF}.get(json.loads(r[0]) if r else "off", ())

def issue(c, user, purpose, s, minutes):
    if c.execute("SELECT COUNT(*) FROM otp_codes WHERE user_id=? AND purpose=? AND created>datetime('now','-1 hour')", (user["id"], purpose)).fetchone()[0] >= (15 if purpose == "login" else 5): raise ValueError("Too many codes requested. Please try again later.")
    x = mailer.cfg(c)
    if not mailer.ready(x): raise ValueError("Email sending is not set up yet. Please contact Becelecia Cashloan.")
    code = f"{secrets.randbelow(1000000):06d}"; tok = secrets.token_urlsafe(16) if purpose == "login" else None
    i = c.execute("INSERT INTO otp_codes(user_id,purpose,token,expires) VALUES(?,?,?,datetime('now',?))", (user["id"], purpose, tok, f"+{minutes} minutes")).lastrowid
    c.execute("UPDATE otp_codes SET code_hash=? WHERE id=?", (_h(i, code), i))
    try: mailer.send(x, user["email"], "Your Becelecia Cashloan verification code", f"Your code is {code}. It expires in {minutes} minutes.\n\nIf you did not ask for this code, ignore this message. Nobody can use your account without it.", s.get("company", {}).get("name", ""))
    except Exception: raise ValueError("We could not send the email. Please try again or contact Becelecia Cashloan.")
    return tok

def check(c, user_id, purpose, code, token=None):
    r = c.execute("SELECT * FROM otp_codes WHERE user_id=? AND purpose=? AND used=0 AND expires>datetime('now') ORDER BY id DESC LIMIT 1", (user_id, purpose)).fetchone()
    if not r or r["attempts"] >= 5 or (token and r["token"] != token): raise ValueError("That code is invalid or has expired")
    if not secrets.compare_digest(_h(r["id"], str(code or "").strip()), r["code_hash"] or ""):
        c.execute("UPDATE otp_codes SET attempts=attempts+1 WHERE id=?", (r["id"],)); c.commit(); raise ValueError("That code is not correct")
    c.execute("UPDATE otp_codes SET used=1 WHERE id=?", (r["id"],))

def route(h, c, m, path, b, s, loan_view):
    if path == "/api/auth/forgot" and m == "POST":
        u = c.execute("SELECT * FROM users WHERE email=? AND active=1", (str(b.get("email", "")).strip().lower(),)).fetchone()
        if u:
            try: issue(c, u, "reset", s, 15); db.audit(c, u["id"], "PASSWORD_RESET_REQUESTED", u["email"])
            except ValueError: pass
        h.send(200, dict(ok=True, message="If that email is registered, a code has been sent.")); return True      # same answer whether or not the email exists
    if path == "/api/auth/reset" and m == "POST":
        email = str(b.get("email", "")).strip().lower(); u = c.execute("SELECT * FROM users WHERE email=? AND active=1", (email,)).fetchone()
        strong(b.get("password"))
        if not u: raise ValueError("That code is invalid or has expired")
        check(c, u["id"], "reset", b.get("code")); c.execute("UPDATE users SET pw=? WHERE id=?", (db.hpw(b["password"]), u["id"])); h.fails.pop(email, None)
        for t in [t for t, x in h.sess.items() if x["id"] == u["id"]]: del h.sess[t]
        db.audit(c, u["id"], "PASSWORD_RESET_COMPLETED", email); h.send(200, dict(ok=True)); return True
    if path == "/api/auth/verify-otp" and m == "POST":
        r = c.execute("SELECT user_id FROM otp_codes WHERE token=? AND purpose='login'", (str(b.get("challenge", "")),)).fetchone()
        if not r: raise ValueError("That code is invalid or has expired")
        check(c, r["user_id"], "login", b.get("code"), b.get("challenge")); u = c.execute("SELECT * FROM users WHERE id=? AND active=1", (r["user_id"],)).fetchone()
        t = secrets.token_urlsafe(32); h.sess[t] = dict(id=u["id"], role=u["role"], name=u["name"]); h.fails.pop(u["email"], None); db.audit(c, u["id"], "LOGIN", u["email"] + " (2-step)")
        h.send(200, dict(token=t, role=u["role"], name=u["name"])); return True
    if path in ("/api/auth/require-2fa", "/api/auth/require-2fa/start"):
        su = h.need("settings"); u = c.execute("SELECT * FROM users WHERE id=?", (su["id"],)).fetchone()
        if path.endswith("start"): issue(c, u, "policy", s, 10); h.send(200, dict(ok=True)); return True
        if m == "POST":
            mode = b.get("mode")
            if mode not in ("off", "admin", "staff"): raise ValueError("Invalid option")
            if mode != "off": check(c, u["id"], "policy", b.get("code"))      # prove this admin can receive codes before forcing it on everyone
            c.execute("INSERT OR REPLACE INTO settings VALUES('require_2fa',?)", (json.dumps(mode),)); db.audit(c, u["id"], "SETTING_CHANGED", "require_2fa", mode)
        r = c.execute("SELECT value FROM settings WHERE key='require_2fa'").fetchone(); h.send(200, dict(mode=json.loads(r[0]) if r else "off")); return True
    if not path.startswith("/api/auth/2fa"): return False
    su = h.user()
    if not su: raise PermissionError("Please log in")
    u = c.execute("SELECT * FROM users WHERE id=?", (su["id"],)).fetchone()
    if path == "/api/auth/2fa": h.send(200, dict(enabled=bool(u["twofa"]))); return True
    if path == "/api/auth/2fa/start": issue(c, u, "2fa", s, 10); h.send(200, dict(ok=True)); return True
    if path == "/api/auth/2fa/confirm":
        check(c, u["id"], "2fa", b.get("code")); c.execute("UPDATE users SET twofa=1 WHERE id=?", (u["id"],)); db.audit(c, u["id"], "TWOFA_ENABLED", u["email"]); h.send(200, dict(ok=True)); return True
    if path == "/api/auth/2fa/disable":
        if not db.check(b.get("password", ""), u["pw"]): raise ValueError("Password is incorrect")
        c.execute("UPDATE users SET twofa=0 WHERE id=?", (u["id"],)); db.audit(c, u["id"], "TWOFA_DISABLED", u["email"]); h.send(200, dict(ok=True)); return True
    return False
