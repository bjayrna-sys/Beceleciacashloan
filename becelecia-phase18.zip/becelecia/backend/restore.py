"""Restore a backup made by backup.py. STOP THE SERVER FIRST. Usage: python3 restore.py BACKUPFILE [--yes]
The current data is saved as a 'pre-restore' backup before anything is replaced."""
import argparse, os, shutil, sqlite3, subprocess, sys, tarfile, tempfile
import backup

def restore(path, yes=False):
    with tempfile.TemporaryDirectory() as tmp:
        src = path
        if path.endswith(".gpg"):
            pf = os.environ.get("BACKUP_PASSPHRASE_FILE") or sys.exit("Set BACKUP_PASSPHRASE_FILE to decrypt this backup")
            src = os.path.join(tmp, "b.tar.gz"); subprocess.run(["gpg", "--batch", "--yes", "--pinentry-mode", "loopback", "--passphrase-file", pf, "-o", src, "-d", path], check=True)
        try:
            with tarfile.open(src) as t:
                names = t.getnames()
                if "becelecia.db" not in names or any(n.startswith(("/", "..")) or ".." in n.split("/") for n in names): sys.exit("This does not look like a valid Becelecia backup")
                t.extractall(tmp, filter="data")
        except (tarfile.TarError, EOFError) as e: sys.exit("Backup file is damaged: " + str(e))
        c = sqlite3.connect(os.path.join(tmp, "becelecia.db")); ok = c.execute("PRAGMA integrity_check").fetchone()[0]; c.close()
        if ok != "ok": sys.exit("Backup database is damaged: " + ok)
        if not yes and input("This REPLACES the current database and documents. Type YES to continue: ") != "YES": sys.exit("Cancelled")
        if os.path.exists(backup.DB): print("Saved current data to", backup.make(os.environ.get("BACKUP_DIR", os.path.join(os.path.dirname(backup.DB), "..", "backups")), prefix="pre-restore"))
        os.makedirs(os.path.dirname(backup.DB), exist_ok=True)
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(backup.DB + ext): os.remove(backup.DB + ext)
        shutil.move(os.path.join(tmp, "becelecia.db"), backup.DB)
        if os.path.isdir(backup.UP): shutil.rmtree(backup.UP)
        if os.path.isdir(os.path.join(tmp, "uploads")): shutil.move(os.path.join(tmp, "uploads"), backup.UP)
    print("Restore complete. Start the server and check the data.")

if __name__ == "__main__":
    a = argparse.ArgumentParser(); a.add_argument("file"); a.add_argument("--yes", action="store_true"); x = a.parse_args(); restore(x.file, x.yes)
