"""Customer credit history and blacklist. Blacklist entries are never deleted: removal keeps the record with who/when/why."""
import base64, os, re, secrets
from datetime import date
import db, notify
from portal import MAGIC, UP

def late_count(c, loan_id, today):
    pays = [(r["d"], r["amount"]) for r in c.execute("SELECT date(created) d,amount FROM payments WHERE loan_id=? AND status='SUCCESS'", (loan_id,))]; cum = late = 0
    for i in c.execute("SELECT due,amount FROM schedule WHERE loan_id=? ORDER BY no", (loan_id,)):
        cum += i["amount"]
        if i["due"] > today: break
        if sum(a for d, a in pays if d <= i["due"]) < cum: late += 1       # instalment not fully covered by its due date
    return late

def history(c, cid, s, loan_view):
    today = date.today().isoformat(); loans = []
    for l in c.execute("SELECT * FROM loans WHERE customer_id=? ORDER BY id", (cid,)):
        v = loan_view(c, l, s); paid = c.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE loan_id=? AND status='SUCCESS'", (l["id"],)).fetchone()[0]
        loans.append(dict(no=l["no"], date=l["created"][:10], principal=l["principal"], total=l["total"], paid=paid, outstanding=v["outstanding"]["total"], status=v["status"], due=l["due_date"], days_overdue=v["days_overdue"],
                          late=late_count(c, l["id"], today), defaulted=v["status"] == "OVERDUE" and v["days_overdue"] > s["grace_days"]))
    ap = c.execute("SELECT COUNT(*), COALESCE(SUM(status='REJECTED'),0) FROM applications WHERE customer_id=?", (cid,)).fetchone()
    summ = dict(loans=len(loans), borrowed=sum(x["principal"] for x in loans), repaid=sum(x["paid"] for x in loans), outstanding=sum(x["outstanding"] for x in loans if x["status"] != "CLEARED"),
                cleared=sum(1 for x in loans if x["status"] == "CLEARED"), active=sum(1 for x in loans if x["status"] != "CLEARED"), late_payments=sum(x["late"] for x in loans), defaulted=sum(1 for x in loans if x["defaulted"]),
                applications=ap[0], rejected=ap[1], blacklisted=bool(c.execute("SELECT blacklisted FROM customers WHERE id=?", (cid,)).fetchone()[0]))
    return dict(summary=summ, loans=loans)

def route(h, c, m, path, b, s, loan_view):
    mm = re.fullmatch(r"/api/customers/(\d+)/credit", path)
    if mm:
        h.need("loans"); cu = c.execute("SELECT * FROM customers WHERE id=?", (mm[1],)).fetchone()
        if not cu: raise ValueError("Customer not found")
        bl = [dict(r) for r in c.execute("SELECT e.id,e.reason,e.notes,e.doc_name,e.added_at,e.active,e.removed_at,e.removal_reason,a.name added_by,r.name removed_by FROM blacklist_entries e LEFT JOIN users a ON a.id=e.added_by LEFT JOIN users r ON r.id=e.removed_by WHERE e.customer_id=? ORDER BY e.id DESC", (cu["id"],))]
        h.send(200, dict(customer=dict(id=cu["id"], no=cu["no"], name=cu["name"], id_number=cu["id_number"], phone=cu["phone"]), blacklist=bl, **history(c, cu["id"], s, loan_view))); return True
    if not path.startswith("/api/blacklist"): return False
    u = h.need("loans")
    if path == "/api/blacklist" and m == "GET":
        h.send(200, [dict(r) for r in c.execute("SELECT e.id,e.customer_id,cu.name,cu.no,e.reason,e.added_at FROM blacklist_entries e JOIN customers cu ON cu.id=e.customer_id WHERE e.active=1 ORDER BY e.id DESC")]); return True
    if path == "/api/blacklist" and m == "POST":
        u = h.need("blacklist"); cu = c.execute("SELECT * FROM customers WHERE id=?", (b.get("customer_id"),)).fetchone()
        if not cu: raise ValueError("Customer not found")
        if not str(b.get("reason", "")).strip(): raise ValueError("A reason is required")
        if c.execute("SELECT 1 FROM blacklist_entries WHERE customer_id=? AND active=1", (cu["id"],)).fetchone(): raise ValueError("Customer is already blacklisted")
        stored = mime = name = None
        if b.get("doc"):
            try: raw = base64.b64decode(b["doc"], validate=True)
            except Exception: raise ValueError("Invalid document")
            mime = next((v for mg, v in MAGIC.items() if raw.startswith(mg)), None)
            if not mime or len(raw) > 5_000_000: raise ValueError("Documents must be JPG, PNG or PDF up to 5MB")
            os.makedirs(UP, exist_ok=True); stored = secrets.token_hex(16); open(os.path.join(UP, stored), "wb").write(raw); name = re.sub(r"[^\w.\-]", "_", str(b.get("doc_name", "document")))[:80]
        eid = c.execute("INSERT INTO blacklist_entries(customer_id,reason,notes,doc_stored,doc_mime,doc_name,added_by) VALUES(?,?,?,?,?,?,?)", (cu["id"], b["reason"].strip()[:300], str(b.get("notes", ""))[:1000], stored, mime, name, u["id"])).lastrowid
        c.execute("UPDATE customers SET blacklisted=1 WHERE id=?", (cu["id"],)); db.audit(c, u["id"], "CUSTOMER_BLACKLISTED", cu["no"], b["reason"].strip()[:300])
        notify.staff(c, ("admin", "loan_officer"), "blacklist", "Customer blacklisted", f"{cu['name']} ({cu['no']}): {b['reason'].strip()[:120]}"); h.send(200, dict(id=eid)); return True
    mm = re.fullmatch(r"/api/blacklist/(\d+)/remove", path)
    if mm and m == "POST":
        u = h.need("blacklist_admin"); e = c.execute("SELECT * FROM blacklist_entries WHERE id=? AND active=1", (mm[1],)).fetchone()
        if not e: raise ValueError("Blacklist entry not found")
        if not str(b.get("reason", "")).strip(): raise ValueError("A reason for removal is required")
        c.execute("UPDATE blacklist_entries SET active=0,removed_by=?,removed_at=CURRENT_TIMESTAMP,removal_reason=? WHERE id=?", (u["id"], b["reason"].strip()[:300], e["id"]))
        if not c.execute("SELECT 1 FROM blacklist_entries WHERE customer_id=? AND active=1", (e["customer_id"],)).fetchone(): c.execute("UPDATE customers SET blacklisted=0 WHERE id=?", (e["customer_id"],))
        db.audit(c, u["id"], "CUSTOMER_UNBLACKLISTED", str(e["customer_id"]), b["reason"].strip()[:300]); h.send(200, dict(ok=True)); return True
    mm = re.fullmatch(r"/api/blacklist/(\d+)/document", path)
    if mm:
        e = c.execute("SELECT * FROM blacklist_entries WHERE id=?", (mm[1],)).fetchone()
        if not e or not e["doc_stored"]: raise ValueError("No document attached")
        h.send(200, open(os.path.join(UP, e["doc_stored"]), "rb").read(), e["doc_mime"]); return True
    return False
