"""Reporting centre. Every report is built from database records and exports to screen (JSON), CSV, Excel and PDF."""
from datetime import date, datetime
from urllib.parse import urlparse, parse_qs
import db, namfisa, finance
from namfisa import N
def rng(q): return finance.day(q.get("from") or "2000-01-01"), finance.day(q.get("to") or date.today())

def r_loans(c, s, lv, q, a, b):
    st = (q.get("filter") or "all").lower(); rows = []; tp = to = 0
    for l in c.execute("SELECT l.*,cu.name FROM loans l JOIN customers cu ON cu.id=l.customer_id WHERE date(l.created) BETWEEN ? AND ? ORDER BY l.id", (a, b)):
        v = lv(c, l, s)
        if st == "defaulted" and not (v["status"] == "OVERDUE" and v["days_overdue"] > s["grace_days"]): continue
        if st in ("active", "overdue", "cleared") and v["status"].lower() != st: continue
        rows.append([l["no"], l["name"], l["created"][:10], N(l["principal"]), N(l["interest"]), N(l["fees"] + l["levy"]), N(l["total"]), l["due_date"], N(v["outstanding"]["total"]), N(v["outstanding"]["penalty"]), v["days_overdue"], v["status"], l["frequency"]]); tp += l["principal"]; to += v["outstanding"]["total"]
    return ["Loan", "Customer", "Date", "Principal", "Interest", "Fees & levies", "Total", "Due", "Outstanding", "Penalty", "Days overdue", "Status", "Frequency"], rows, [("Loans", len(rows)), ("Principal", N(tp)), ("Outstanding", N(to))]
def r_customers(c, s, lv, q, a, b):
    rows = []
    for cu in c.execute("SELECT * FROM customers ORDER BY id"):
        ls = [lv(c, l, s) for l in c.execute("SELECT * FROM loans WHERE customer_id=?", (cu["id"],))]; live = [v for v in ls if v["status"] != "CLEARED"]
        lp = c.execute("SELECT MAX(date(p.created)) FROM payments p JOIN loans l ON l.id=p.loan_id WHERE l.customer_id=? AND p.status='SUCCESS'", (cu["id"],)).fetchone()[0]
        rows.append([cu["no"], cu["name"], cu["id_number"], cu["phone"] or "", cu["employer"] or "", N(cu["salary_cents"]), len(live), N(sum(v["outstanding"]["total"] for v in live)), lp or "", "Blacklisted" if cu["blacklisted"] else "Active borrower" if live else "No active loan"])
    if (q.get("filter") or "").lower() == "outstanding": rows = [r for r in rows if r[6]]
    return ["No", "Name", "ID", "Phone", "Employer", "Income", "Active loans", "Outstanding", "Last payment", "Status"], rows, [("Customers", len(rows))]
def r_payments(c, s, lv, q, a, b):
    f = (q.get("filter") or "").strip(); w, p = ["date(p.created) BETWEEN ? AND ?"], [a, b]
    if f: w.append("(p.status=? OR p.method=?)"); p += [f.upper(), f]
    rows = []; tot = 0
    for x in c.execute(f"SELECT p.*,l.no lno,cu.name cn,r.no rno,u.name uby FROM payments p JOIN loans l ON l.id=p.loan_id JOIN customers cu ON cu.id=l.customer_id LEFT JOIN receipts r ON r.payment_id=p.id LEFT JOIN users u ON u.id=p.user_id WHERE {' AND '.join(w)} ORDER BY p.id", p):
        rows.append([x["created"][:10], x["rno"] or "", x["lno"], x["cn"], x["method"] + (" (TEST)" if x["mode"] == "test" and x["method"] == "Online gateway" else ""), x["status"], N(x["amount"]), x["uby"] or "", x["reference"]]); tot += x["amount"] if x["status"] == "SUCCESS" else 0
    return ["Date", "Receipt", "Loan", "Customer", "Method", "Status", "Amount", "Received by", "Reference"], rows, [("Payments", len(rows)), ("Successful total", N(tot))]
def r_expenses(c, s, lv, q, a, b):
    f = (q.get("filter") or "").strip(); w, p = ["e.date BETWEEN ? AND ?"], [a, b]
    if f: w.append("k.name=?"); p.append(f)
    rows = []; by = {}
    for e in c.execute(f"SELECT e.*,k.name cat,u.name uby FROM expenses e JOIN expense_categories k ON k.id=e.category_id LEFT JOIN users u ON u.id=e.user_id WHERE {' AND '.join(w)} ORDER BY e.date,e.id", p):
        rows.append([e["date"], e["cat"], e["payee"], N(e["amount"]), e["method"], e["reference"] or "", e["description"] or "", e["uby"] or ""]); by[e["cat"]] = by.get(e["cat"], 0) + e["amount"]
    return ["Date", "Category", "Payee", "Amount", "Method", "Reference", "Description", "By"], rows, [("Total expenses", N(sum(by.values())))] + [(f"  {k}", N(v)) for k, v in by.items()]
def r_cashflow(c, s, lv, q, a, b):
    rows = [[x["date"], "CASH" if x["method"] == "Cash" else "BANK", "Payment", f"{x['lno']} {x['method']}", N(x["amount"]), ""] for x in c.execute(f"SELECT date(p.created) date,p.method,p.amount,l.no lno FROM payments p JOIN loans l ON l.id=p.loan_id WHERE p.status='SUCCESS' AND {finance.REAL} AND date(p.created) BETWEEN ? AND ?", (a, b))]
    rows += [[x["date"], x["account"], x["category"], x["description"] or "", N(x["amount"]) if x["kind"] == "IN" else "", N(x["amount"]) if x["kind"] == "OUT" else ""] for x in c.execute("SELECT * FROM cash_transactions WHERE date BETWEEN ? AND ?", (a, b))]
    rows += [[x["date"], "CASH" if x["method"] == "Cash" else "BANK", "Expense", f"{x['payee']}", "", N(x["amount"])] for x in c.execute("SELECT * FROM expenses WHERE date BETWEEN ? AND ?", (a, b))]
    rows.sort(key=lambda r: r[0]); i = sum(round(float(r[4] or 0) * 100) for r in rows); o = sum(round(float(r[5] or 0) * 100) for r in rows)
    return ["Date", "Account", "Type", "Description", "In", "Out"], rows, [("Total in", N(i)), ("Total out", N(o)), ("Net cash flow", N(i - o))]
def r_income(c, s, lv, q, a, b):
    rows = []; ti = tp = tf = 0
    for d, in c.execute(f"SELECT DISTINCT date(p.created) FROM payments p WHERE p.status='SUCCESS' AND {finance.REAL} AND date(p.created) BETWEEN ? AND ? ORDER BY 1", (a, b)).fetchall():
        r, _ = finance.collected(c, d, d); rows.append([d, N(r.get("interest", 0)), N(r.get("penalty", 0)), N(r.get("fees", 0))]); ti += r.get("interest", 0); tp += r.get("penalty", 0); tf += r.get("fees", 0)
    ex = c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date BETWEEN ? AND ?", (a, b)).fetchone()[0]
    return ["Date", "Interest collected", "Penalties collected", "Fees & levies collected"], rows, [("Interest income", N(ti)), ("Penalty income", N(tp)), ("Fees & levies collected (pass-through, not in profit)", N(tf)), ("Expenses", N(ex)), ("Profit", N(ti + tp - ex))]
def r_investors(c, s, lv, q, a, b):
    from investors import account
    rows = []
    for i in c.execute("SELECT * FROM investors ORDER BY id"):
        x = account(c, i["id"], s, lv); rows.append([i["name"], N(x["capital"]), N(x["allocated"]), N(x["recovered"]), N(x["outstanding"]), N(x["available"]), N(x["earnings"])])
    return ["Investor", "Capital", "Allocated", "Recovered", "Outstanding", "Available", "Earnings"], rows, [("Investors", len(rows))]
def r_blacklist(c, s, lv, q, a, b):
    rows = [[x["name"], x["no"], x["id_number"], x["reason"], x["added_at"][:10], x["by"] or "", "Active" if x["active"] else "Removed " + (x["removed_at"] or "")[:10]] for x in c.execute("SELECT e.*,cu.name,cu.no,cu.id_number,u.name by FROM blacklist_entries e JOIN customers cu ON cu.id=e.customer_id LEFT JOIN users u ON u.id=e.added_by WHERE date(e.added_at) BETWEEN ? AND ? ORDER BY e.id", (a, b))]
    if (q.get("filter") or "").lower() == "active": rows = [r for r in rows if r[6] == "Active"]
    return ["Customer", "No", "ID", "Reason", "Date added", "Added by", "Status"], rows, [("Entries", len(rows))]
def r_credit(c, s, lv, q, a, b):
    import credit
    rows = []
    for cu in c.execute("SELECT * FROM customers ORDER BY id"):
        x = credit.history(c, cu["id"], s, lv)["summary"]
        rows.append([cu["no"], cu["name"], x["loans"], N(x["borrowed"]), N(x["repaid"]), N(x["outstanding"]), x["cleared"], x["late_payments"], x["defaulted"], x["applications"], x["rejected"], "Blacklisted" if x["blacklisted"] else "OK"])
    return ["No", "Customer", "Loans", "Borrowed", "Repaid", "Outstanding", "Cleared", "Late payments", "Defaults", "Applications", "Rejected", "Status"], rows, [("Customers", len(rows))]
REPORTS = {"blacklist": ("Blacklisted customers (filter: active)", r_blacklist), "credit": ("Customer credit history", r_credit), "loans": ("Loan report (filter: all, active, overdue, cleared, defaulted)", r_loans), "customers": ("Customer register (filter: outstanding)", r_customers), "payments": ("Payments (filter: status or method, e.g. FAILED, PENDING, EFT)", r_payments),
           "expenses": ("Expenses (filter: category name)", r_expenses), "cashflow": ("Cash flow", r_cashflow), "income": ("Income and profit", r_income), "investors": ("Investor balances", r_investors)}

def route(h, c, m, path, b, s, loan_view):
    if not path.startswith("/api/reports"): return False
    u = h.need("reports")
    if path == "/api/reports/list": h.send(200, {k: v[0] for k, v in REPORTS.items()}); return True
    name = path.rsplit("/", 1)[-1]
    if name not in REPORTS: raise ValueError("Unknown report")
    q = {k: v[0] for k, v in parse_qs(urlparse(h.path).query).items()}; a, e = rng(q); hd, rows, summ = REPORTS[name][1](c, s, loan_view, q, a, e)
    t = dict(company=s.get("company", {}).get("name", "Becelecia Cashloan CC"), title=REPORTS[name][0].split(" (")[0], start=a, end=e, gen=datetime.now().strftime("%Y-%m-%d %H:%M"), by=u["name"]); rep = dict(summary=summ, headers=hd, rows=rows)
    fmt = q.get("format", "json"); db.audit(c, u["id"], "REPORT_GENERATED", name, f"{a}..{e} {fmt}"); fn = f"{name}_{a}_{e}"
    if fmt == "csv": h.send(200, namfisa.to_csv(t, rep), "text/csv", fn + ".csv")
    elif fmt == "xlsx": h.send(200, namfisa.to_xlsx(t, rep), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fn + ".xlsx")
    elif fmt == "pdf": h.send(200, namfisa.to_pdf(t, rep), "application/pdf", fn + ".pdf")
    else: h.send(200, dict(t, summary=summ, headers=hd, rows=rows[:200], total_rows=len(rows)))
    return True
