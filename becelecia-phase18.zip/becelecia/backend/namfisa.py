"""NAMFISA reporting. Built only from database records. Bank charges are never included.
Output columns are configurable (Regulatory Reporting Settings); if NAMFISA issues an official template, adjust COLS/fields here."""
import csv, io, json, os, re
from datetime import date, datetime, timedelta
from urllib.parse import urlparse, parse_qs
import db
LOGO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend", "logo.jpeg")
N = lambda c: f"{c/100:.2f}"
COLS = {  # key: (header, getter(loan_row, view, loan_date))
 "loan_no": ("Loan no", lambda r, v: r["no"]), "customer_no": ("Customer no", lambda r, v: r["cno"]),
 "customer_name": ("Customer", lambda r, v: r["name"]), "id_number": ("ID number", lambda r, v: r["id_number"]),
 "date": ("Loan date", lambda r, v: r["created"][:10]), "principal": ("Principal", lambda r, v: N(r["principal"])),
 "interest": ("Interest", lambda r, v: N(r["interest"])), "levy": ("NAMFISA levy", lambda r, v: N(r["levy"])),
 "stamp_duty": ("Stamp duty", lambda r, v: N(r["stamp"])), "due_date": ("Due date", lambda r, v: r["due_date"]),
 "frequency": ("Frequency", lambda r, v: r["frequency"]),
 "outstanding": ("Outstanding (principal+interest+penalty)", lambda r, v: N(v["outstanding"]["principal"] + v["outstanding"]["interest"] + v["outstanding"]["penalty"])),
 "status": ("Status", lambda r, v: v["status"]), "days_overdue": ("Days overdue", lambda r, v: v["days_overdue"])}
DEFAULT_FIELDS = list(COLS)

def period(p, d, st, en):
    d = date.fromisoformat(d) if d else date.today()
    if p == "daily": return d, d
    if p == "weekly": a = d - timedelta(days=d.weekday()); return a, a + timedelta(days=6)
    if p == "monthly": a = d.replace(day=1); return a, (a.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    if p == "quarterly":
        m = 3 * ((d.month - 1) // 3) + 1; a = date(d.year, m, 1); e = date(d.year + (m == 10), (m + 3 - 1) % 12 + 1, 1) - timedelta(days=1); return a, e
    if p == "custom":
        a, e = date.fromisoformat(st), date.fromisoformat(en)
        if e < a: raise ValueError("End date is before start date")
        return a, e
    raise ValueError("Invalid period")

def build(c, a, e, s, loan_view, fields):
    r = (a.isoformat(), e.isoformat()); D = lambda col: f"date({col}) BETWEEN ? AND ?"
    ap = {x["status"]: x["n"] for x in c.execute(f"SELECT status,COUNT(*) n FROM applications WHERE {D('created')} GROUP BY status", r)}
    rows = c.execute(f"SELECT l.*,c.no cno,c.name,c.id_number FROM loans l JOIN customers c ON c.id=l.customer_id WHERE {D('l.created')} ORDER BY l.id", r).fetchall()
    reg = [(x, loan_view(c, x, s)) for x in rows]
    col = {x["bucket"]: x["t"] for x in c.execute(f"SELECT a.bucket,SUM(a.amount) t FROM allocations a JOIN payments p ON p.id=a.payment_id WHERE p.status='SUCCESS' AND {D('p.created')} GROUP BY a.bucket", r)}
    pf = [loan_view(c, x, s) for x in c.execute("SELECT * FROM loans")]
    live = [v for v in pf if v["status"] != "CLEARED"]; o = lambda k: sum(v["outstanding"][k] for v in live)
    cleared = sum(1 for v in pf if v["status"] == "CLEARED" and r[0] <= (c.execute("SELECT MAX(date(created)) FROM payments WHERE loan_id=?", (v["id"],)).fetchone()[0] or "") <= r[1])
    summary = [("Applications received", sum(ap.values())), ("Applications approved", ap.get("APPROVED", 0)), ("Applications rejected", ap.get("REJECTED", 0)),
      ("Loans disbursed (count)", len(reg)), ("Principal disbursed (N$)", N(sum(x["principal"] for x, _ in reg))),
      ("Interest charged (N$)", N(sum(x["interest"] for x, _ in reg))), ("NAMFISA levy charged (N$)", N(sum(x["levy"] for x, _ in reg))),
      ("Stamp duty charged (N$)", N(sum(x["stamp"] for x, _ in reg))),
      ("Repayments received: principal (N$)", N(col.get("principal", 0))), ("Repayments received: interest (N$)", N(col.get("interest", 0))),
      ("Repayments received: penalties (N$)", N(col.get("penalty", 0))), ("Loans cleared in period", cleared),
      ("Outstanding loans (as at generation date)", len(live)), ("Outstanding principal (N$)", N(o("principal"))),
      ("Outstanding interest (N$)", N(o("interest"))), ("Outstanding penalties (N$)", N(o("penalty"))),
      ("Overdue loans", sum(1 for v in live if v["status"] == "OVERDUE")),
      ("Defaulted loans (overdue beyond grace)", sum(1 for v in live if v["days_overdue"] > s["grace_days"]))]
    return dict(summary=summary, headers=[COLS[f][0] for f in fields], rows=[[COLS[f][1](x, v) for f in fields] for x, v in reg])

def to_csv(t, rep):
    o = io.StringIO(); w = csv.writer(o); w.writerow([t["title"], t["start"], t["end"], "Generated " + t["gen"], "By " + t["by"]]); w.writerows(rep["summary"]); w.writerow([]); w.writerow(rep["headers"]); w.writerows(rep["rows"]); return o.getvalue().encode()

def to_xlsx(t, rep):
    from openpyxl import Workbook; from openpyxl.styles import Font, PatternFill
    wb = Workbook(); ws = wb.active; ws.title = "Summary"
    for x in ([t["company"]], [t["title"]], [f"{t['start']} to {t['end']}"], [f"Generated {t['gen']} by {t['by']}"], []): ws.append(x)
    ws["A1"].font = Font(bold=True, size=14, color="1F4AA8")
    for x in rep["summary"]: ws.append(list(x))
    ws.column_dimensions["A"].width = 48; w2 = wb.create_sheet("Loan register"); w2.append(rep["headers"])
    for cell in w2[1]: cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor="1F4AA8")
    for x in rep["rows"]: w2.append(x)
    b = io.BytesIO(); wb.save(b); return b.getvalue()

def to_pdf(t, rep):
    from reportlab.lib.pagesizes import A4, landscape; from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
    from reportlab.lib.styles import getSampleStyleSheet; from reportlab.lib import colors
    b = io.BytesIO(); st = getSampleStyleSheet(); blue = colors.HexColor("#1F4AA8")
    def foot(cv, d): cv.setFont("Helvetica", 8); cv.drawRightString(800, 20, f"Page {d.page}"); cv.drawString(40, 20, f"{t['company']} · generated {t['gen']} by {t['by']}")
    el = [Image(LOGO, 150, 62, kind="proportional") if os.path.exists(LOGO) else Spacer(1, 1), Paragraph(t["title"], st["Title"]), Paragraph(f"Period: {t['start']} to {t['end']}", st["Normal"]), Spacer(1, 10)]
    ts = [("GRID", (0, 0), (-1, -1), .25, colors.lightgrey), ("FONTSIZE", (0, 0), (-1, -1), 7.5)]
    el += [Table([[str(a), str(v)] for a, v in rep["summary"]], colWidths=[280, 120], style=ts + [("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#EAF0FB"))]), Spacer(1, 12)]
    if rep["rows"]: el.append(Table([rep["headers"]] + [[str(x) for x in r] for r in rep["rows"]], repeatRows=1, style=ts + [("BACKGROUND", (0, 0), (-1, 0), blue), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]))
    SimpleDocTemplate(b, pagesize=landscape(A4), leftMargin=40, rightMargin=40).build(el, onFirstPage=foot, onLaterPages=foot); return b.getvalue()

def route(h, c, m, path, b, s, loan_view):
    if path == "/api/namfisa/settings":
        u = h.need("settings")
        if m == "POST":
            f = b.get("fields", [])
            if not f or any(x not in COLS for x in f): raise ValueError("Invalid report fields")
            c.execute("INSERT OR REPLACE INTO settings VALUES('namfisa_fields',?)", (json.dumps(f),)); db.audit(c, u["id"], "NAMFISA_SETTINGS_CHANGED", "namfisa_fields", json.dumps(f))
        h.send(200, dict(fields=json.loads(c.execute("SELECT value FROM settings WHERE key='namfisa_fields'").fetchone()[0]) if c.execute("SELECT 1 FROM settings WHERE key='namfisa_fields'").fetchone() else DEFAULT_FIELDS, available=list(COLS))); return True
    if path == "/api/namfisa/report":
        u = h.need("reports"); q = {k: v[0] for k, v in parse_qs(urlparse(h.path).query).items()}
        a, e = period(q.get("period", "monthly"), q.get("date"), q.get("start"), q.get("end"))
        fields = s.get("namfisa_fields", DEFAULT_FIELDS); rep = build(c, a, e, s, loan_view, fields)
        t = dict(company=s.get("company", {}).get("name", "Becelecia Cashloan CC"), title="NAMFISA Report (" + q.get("period", "monthly").title() + ")", start=a.isoformat(), end=e.isoformat(), gen=datetime.now().strftime("%Y-%m-%d %H:%M"), by=u["name"])
        fmt = q.get("format", "json"); db.audit(c, u["id"], "REPORT_GENERATED", "namfisa", f"{a}..{e} {fmt}")
        fn = f"namfisa_{a}_{e}"
        if fmt == "csv": h.send(200, to_csv(t, rep), "text/csv", fn + ".csv")
        elif fmt == "xlsx": h.send(200, to_xlsx(t, rep), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fn + ".xlsx")
        elif fmt == "pdf": h.send(200, to_pdf(t, rep), "application/pdf", fn + ".pdf")
        else: h.send(200, dict(t, **rep))
        return True
    return False
