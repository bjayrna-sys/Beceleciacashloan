"""Automatic email through SMTP (works with a Gmail App Password, or any business SMTP). Settings are stored server-side; the password is never sent back to the browser."""
import json, smtplib, ssl
from email.message import EmailMessage
import db, notify
def cfg(c): return notify.get(c, "smtp", {})
def ready(x): return bool(x.get("host") and x.get("from_email"))
def send(x, to, subject, body, company=""):
    m = EmailMessage(); m["From"] = f'{x.get("from_name") or "Becelecia Cashloan"} <{x["from_email"]}>'; m["To"] = to; m["Subject"] = subject
    m.set_content(body + ("\n\n--\n" + company if company else ""))
    sec, ctx = x.get("security", "starttls"), ssl.create_default_context()
    s = smtplib.SMTP_SSL(x["host"], int(x["port"]), timeout=15, context=ctx) if sec == "ssl" else smtplib.SMTP(x["host"], int(x["port"]), timeout=15)
    try:
        if sec == "starttls": s.starttls(context=ctx)
        if x.get("user"): s.login(x["user"], x.get("password", ""))
        s.send_message(m)
    finally:
        try: s.quit()
        except Exception: pass
def deliver_pending(c, s):
    x = cfg(c)
    if not ready(x) or not notify.get(c, "notify_channels", notify.CHANNELS).get("email"): return 0
    co = s.get("company", {}); footer = f'{co.get("name", "Becelecia Cashloan CC")}, {co.get("address", "")}, {co.get("phone", "")}'; n = 0
    for r in c.execute("SELECT id,to_addr,subject,body FROM outbox WHERE channel='email' AND status='TO_SEND' AND attempts<3 ORDER BY id LIMIT 20").fetchall():
        try: send(x, r["to_addr"], r["subject"] or "Becelecia Cashloan", r["body"], footer); c.execute("UPDATE outbox SET status='SENT',error=NULL WHERE id=?", (r["id"],)); n += 1
        except Exception as e: c.execute("UPDATE outbox SET attempts=attempts+1,error=? WHERE id=?", (f"{type(e).__name__}: {str(e)[:120]}", r["id"]))   # after 3 tries it stays in 'Messages to send' for manual sending
    return n
def route(h, c, m, path, b, s, loan_view):
    if path not in ("/api/notifications/email-settings", "/api/notifications/email-test"): return False
    u = h.need("settings"); x = cfg(c)
    if path.endswith("test"):
        try: send(x, str(b.get("to", "")).strip(), "Test email from Becelecia Cashloan", "This is a test. Email sending is working.") if ready(x) else (_ for _ in ()).throw(ValueError("Save the email settings first"))
        except Exception as e: h.send(200, dict(ok=False, error=f"{type(e).__name__}: {str(e)[:150]}")); return True
        db.audit(c, u["id"], "EMAIL_TEST", str(b.get("to", ""))); h.send(200, dict(ok=True)); return True
    if m == "POST":
        try: port = int(b.get("port") or 587)
        except ValueError: raise ValueError("Port must be a number")
        if b.get("security", "starttls") not in ("starttls", "ssl", "none"): raise ValueError("Invalid security option")
        new = dict(host=str(b.get("host", "")).strip(), port=port, security=b.get("security", "starttls"), user=str(b.get("user", "")).strip(), from_email=str(b.get("from_email", "")).strip(), from_name=str(b.get("from_name", "")).strip()[:60], password=b["password"] if b.get("password") else x.get("password", ""))
        c.execute("INSERT OR REPLACE INTO settings VALUES('smtp',?)", (json.dumps(new),)); db.audit(c, u["id"], "EMAIL_SETTINGS_CHANGED", new["host"]); x = new
    h.send(200, dict({k: v for k, v in x.items() if k != "password"}, has_password=bool(x.get("password")))); return True
