"""Admin settings. API uses display units (percent, N$); storage uses fractions and cents (what engine.py reads)."""
import json
import db, payments
PCT = {"interest_pct": "rate_monthly", "levy_pct": "levy_pct", "bank_pct": "bank_pct", "penalty_pct": "penalty_pct", "investor_pct": "investor_pct", "investor_earning_pct": "investor_earning_pct"}
MONEY = {"stamp": "stamp_cents", "min_amount": "min_cents", "max_amount": "max_cents"}
INTS = {"min_days": "min_days", "max_days": "max_days", "grace_days": "grace_days", "penalty_max_months": "penalty_max_months"}
BUCKETS = {"penalty", "fees", "interest", "principal"}
COMPANY = {"name": "Becelecia Cashloan CC", "address": "Shop No. 16, Pelican Mall, Walvis Bay, Namibia", "phone": "+264 81 472 2735", "website": "www.beceleciacashloan.com"}

def view(s):
    out = {k: round(s[v] * 100, 4) for k, v in PCT.items()}
    out.update({k: s[v] / 100 for k, v in MONEY.items()}); out.update({k: s[v] for k, v in INTS.items()}); out["alloc_order"] = s["alloc_order"]
    return out

def parse(loan):
    new = {}
    for k, v in loan.items():
        try:
            if k in PCT:
                x = float(v)
                if not 0 <= x <= 100: raise ValueError
                new[PCT[k]] = round(x / 100, 6)
            elif k in MONEY:
                x = float(v)
                if x < 0: raise ValueError
                new[MONEY[k]] = round(x * 100)
            elif k in INTS:
                x = int(float(v))
                if x < 0 or (k == "penalty_max_months" and x > 12) or (k == "grace_days" and x > 90): raise ValueError
                new[INTS[k]] = x
            elif k == "alloc_order":
                parts = [p.strip() for p in str(v).split(",")]
                if set(parts) != BUCKETS or len(parts) != 4: raise ValueError
                new[k] = ",".join(parts)
            else: raise KeyError
        except KeyError: raise ValueError(f"Unknown setting: {k}")
        except ValueError: raise ValueError(f"Invalid value for {k}")
    return new

def route(h, c, m, path, b, s, loan_view):
    if path != "/api/settings": return False
    u = h.need("settings")
    if m == "POST":
        new = parse(b.get("loan", {})); merged = dict(s, **new)
        if merged["min_cents"] >= merged["max_cents"]: raise ValueError("Minimum loan must be less than maximum loan")
        if merged["min_days"] >= merged["max_days"]: raise ValueError("Minimum term must be less than maximum term")
        if merged["min_cents"] < 1: raise ValueError("Minimum loan must be greater than zero")
        changes = {k: {"old": s[k], "new": v} for k, v in new.items() if s[k] != v}
        for k, v in new.items(): db.audit(c, u["id"], "SETTING_CHANGED", k, json.dumps(dict(old=s[k], new=v))) if s[k] != v else None; c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, json.dumps(v)))
        if "company" in b:
            old = s.get("company", COMPANY); co = {k: str(b["company"].get(k, old[k])).strip()[:200] for k in COMPANY}
            if not co["name"]: raise ValueError("Company name is required")
            if co != old: db.audit(c, u["id"], "SETTING_CHANGED", "company", json.dumps(dict(old=old, new=co)))
            c.execute("INSERT OR REPLACE INTO settings VALUES('company',?)", (json.dumps(co),)); s = dict(s, company=co)
        s = dict(s, **new)
    h.send(200, dict(loan=view(s), company=s.get("company", COMPANY), payment=dict(mode=payments.get(c, "payment_mode", "test"), methods=payments.get(c, "payment_methods", payments.DEFAULT_METHODS), live_credentials_configured=bool(payments.get(c, "payment_credentials"))))); return True
