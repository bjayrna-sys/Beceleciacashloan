"""Loan calculation engine. All money is integer cents. Rates come from settings, never hard-coded."""
from math import ceil
from datetime import date, timedelta
DEFAULTS = dict(rate_monthly=0.30, levy_pct=0.013, stamp_cents=500, bank_pct=0.05,
    penalty_pct=0.05, penalty_max_months=3, grace_days=7, investor_pct=0.15,
    min_cents=10000, max_cents=2000000, min_days=10, max_days=61,
    alloc_order="penalty,fees,interest,principal", investor_earning_pct=0.0)
STEP = {"weekly": 7, "biweekly": 14, "monthly": 30}
def quote(p, days, freq, s, start=None):
    if not s["min_cents"] <= p <= s["max_cents"]: raise ValueError("Loan amount is outside the configured limits")
    if not s["min_days"] <= days <= s["max_days"]: raise ValueError("Loan term is outside the configured limits")
    if freq not in STEP: raise ValueError("Invalid repayment frequency")
    start = start or date.today()
    interest = round(p * s["rate_monthly"] * days / 30)   # flat, prorated by days/30
    levy = round(p * s["levy_pct"])                        # NAMFISA levy (rule configurable)
    bank = round(p * s["bank_pct"])
    fees = s["stamp_cents"] + bank                         # stamp duty + bank charge
    total = p + interest + levy + fees
    n = ceil(days / STEP[freq]); base = total // n
    sched = [dict(no=i, due=(start + timedelta(days=min(days, i * STEP[freq]))).isoformat(),
                  amount=base if i < n else total - base * (n - 1)) for i in range(1, n + 1)]
    return dict(principal=p, interest=interest, levy=levy, stamp=s["stamp_cents"], bank=bank, fees=fees,
                total=total, schedule=sched, due_date=sched[-1]["due"], investor_share=round(p * s["investor_pct"]))
def penalty_due(outstanding_pi, due_date, s, today=None):
    """5%/month (configurable) of unpaid principal+interest after grace, capped at N months."""
    today = today or date.today()
    late = (today - date.fromisoformat(due_date)).days - s["grace_days"]
    if late <= 0 or outstanding_pi <= 0: return 0
    return round(outstanding_pi * s["penalty_pct"] * min(s["penalty_max_months"], ceil(late / 30)))
def allocate(bal, amount, order):
    """Traceable split of a payment across buckets in configured order."""
    out, left = {}, amount
    for b in order.split(","):
        t = min(left, max(0, bal.get(b, 0))); out[b] = t; left -= t
    out["overpayment"] = left
    return out
