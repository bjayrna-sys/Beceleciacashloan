"""Staff user management, own-password change, logout and the audit log viewer (admin only)."""
import re
import db
ROLES = ("admin", "loan_officer", "cashier", "accountant")
def strong(pw):
    if len(pw or "") < 10 or not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw): raise ValueError("Password must be at least 10 characters with letters and numbers")

def drop_sessions(h, uid):
    for t in [t for t, u in h.sess.items() if u["id"] == uid]: del h.sess[t]

def route(h, c, m, path, b, s, loan_view):
    if path == "/api/auth/logout" and m == "POST":
        h.sess.pop(h.headers.get("Authorization", "").replace("Bearer ", ""), None); h.send(200, dict(ok=True)); return True
    if path == "/api/auth/change-password" and m == "POST":
        u = h.user()
        if not u: raise PermissionError("Please log in")
        r = c.execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone()
        if not db.check(b.get("old", ""), r["pw"]): raise ValueError("Current password is incorrect")
        strong(b.get("new")); c.execute("UPDATE users SET pw=? WHERE id=?", (db.hpw(b["new"]), u["id"])); db.audit(c, u["id"], "PASSWORD_CHANGED", r["email"])
        keep = h.headers.get("Authorization", "").replace("Bearer ", "")
        for t in [t for t, x in h.sess.items() if x["id"] == u["id"] and t != keep]: del h.sess[t]
        h.send(200, dict(ok=True)); return True
    if path == "/api/users":
        u = h.need("settings")
        if m == "GET": h.send(200, [dict(r) for r in c.execute("SELECT id,email,name,role,active,twofa FROM users WHERE role!='customer' ORDER BY id")]); return True
        email = str(b.get("email", "")).strip().lower()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email): raise ValueError("Enter a valid email address")
        if not str(b.get("name", "")).strip(): raise ValueError("Name is required")
        if b.get("role") not in ROLES: raise ValueError("Invalid role")
        strong(b.get("password"))
        if c.execute("SELECT 1 FROM users WHERE email=?", (email,)).fetchone(): raise ValueError("Email already registered")
        uid = c.execute("INSERT INTO users(email,name,role,pw) VALUES(?,?,?,?)", (email, b["name"].strip()[:100], b["role"], db.hpw(b["password"]))).lastrowid
        db.audit(c, u["id"], "USER_CREATED", email, b["role"]); h.send(200, dict(id=uid)); return True
    import re as _r
    mm = _r.fullmatch(r"/api/users/(\d+)/(update|reset-password)", path)
    if mm and m == "POST":
        u = h.need("settings"); t = c.execute("SELECT * FROM users WHERE id=? AND role!='customer'", (mm[1],)).fetchone()
        if not t: raise ValueError("User not found")
        if mm[2] == "reset-password":
            strong(b.get("password")); c.execute("UPDATE users SET pw=? WHERE id=?", (db.hpw(b["password"]), t["id"])); h.fails.pop(t["email"], None)
            drop_sessions(h, t["id"]); db.audit(c, u["id"], "PASSWORD_RESET", t["email"]); h.send(200, dict(ok=True)); return True
        role, active = b.get("role", t["role"]), int(bool(b.get("active", t["active"])))
        if role not in ROLES: raise ValueError("Invalid role")
        if t["role"] == "investor" and role != "investor": raise ValueError("Investor accounts are managed in the Investors section")
        if t["id"] == u["id"] and (role != t["role"] or not active): raise ValueError("You cannot change your own role or disable your own account")
        others = c.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1 AND id!=?", (t["id"],)).fetchone()[0]
        if t["role"] == "admin" and (role != "admin" or not active) and others == 0: raise ValueError("At least one active administrator is required")
        if b.get("twofa") == 0: c.execute("UPDATE users SET twofa=0 WHERE id=?", (t["id"],)); db.audit(c, u["id"], "TWOFA_RESET_BY_ADMIN", t["email"])
        c.execute("UPDATE users SET role=?, active=? WHERE id=?", (role, active, t["id"]))
        if role != t["role"] or not active: drop_sessions(h, t["id"])
        db.audit(c, u["id"], "USER_UPDATED", t["email"], f"role {t['role']}->{role}, active {t['active']}->{active}"); h.send(200, dict(ok=True)); return True
    if path == "/api/audit" and m == "GET":
        h.need("settings")
        from urllib.parse import urlparse, parse_qs
        q = {k: v[0] for k, v in parse_qs(urlparse(h.path).query).items()}; w, p = ["1=1"], []
        if q.get("action"): w.append("a.action LIKE ?"); p.append(f"%{q['action']}%")
        if q.get("q"): w.append("(a.record LIKE ? OR a.detail LIKE ? OR u.name LIKE ?)"); p += [f"%{q['q']}%"] * 3
        if q.get("from"): w.append("date(a.at) >= ?"); p.append(q["from"])
        if q.get("to"): w.append("date(a.at) <= ?"); p.append(q["to"])
        W = " AND ".join(w); total = c.execute(f"SELECT COUNT(*) FROM audit a LEFT JOIN users u ON u.id=a.user_id WHERE {W}", p).fetchone()[0]
        pages = max(1, -(-total // 50)); page = min(max(int(q.get("page", 1) or 1), 1), pages)
        rows = [dict(r) for r in c.execute(f"SELECT a.id,a.at,u.name user,a.action,a.record,a.detail FROM audit a LEFT JOIN users u ON u.id=a.user_id WHERE {W} ORDER BY a.id DESC LIMIT 50 OFFSET ?", p + [(page - 1) * 50])]
        h.send(200, dict(rows=rows, page=page, pages=pages, total=total)); return True
    return False
