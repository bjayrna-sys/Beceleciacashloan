"""Payments: cashier receipts, payment-provider abstraction, sandbox (TEST) gateway, signed webhooks.
Money is cents. A payment row starts PENDING; allocation + receipt only happen in settle(), inside the request's DB transaction.
Webhook signature = HMAC-SHA256(WEBHOOK_SECRET, canonical JSON of the body) in header X-Signature."""
import hmac, hashlib, json, os, re, secrets, sqlite3
from urllib.parse import urlparse, parse_qs
import db, engine, notify
SECRET = os.environ.get("WEBHOOK_SECRET", "dev-webhook-secret-change-me").encode()
DEFAULT_METHODS = ["Cash", "EFT", "Bank transfer", "eWallet", "EasyWallet", "GreenWallet"]
canon = lambda d: json.dumps(d, sort_keys=True, separators=(",", ":")).encode()
sign = lambda d: hmac.new(SECRET, canon(d), hashlib.sha256).hexdigest()
M = lambda c: f"N${c/100:,.2f}"
DEFAULT_BANK = {"bank": "", "account_name": "Becelecia Cashloan CC", "account_number": "", "branch": "", "note": "Use your loan number as the payment reference."}

class Sandbox:        # TEST mode: no real money moves
    def initiate(self, ref): return "SBX-" + secrets.token_hex(5)
class Live:           # plug a real Namibian provider in here: initiate() -> provider reference; webhook -> handle_event()
    def initiate(self, ref): raise ValueError("No live payment provider is connected yet. Switch to TEST mode.")

def get(c, key, default=None):
    r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone(); return json.loads(r[0]) if r else default
def put(c, key, val): c.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, json.dumps(val)))

def settle(c, pid, s, loan_view, uid=None):
    p = c.execute("SELECT * FROM payments WHERE id=?", (pid,)).fetchone()
    if p["status"] != "PENDING": return None            # idempotent: never settle twice
    l = c.execute("SELECT * FROM loans WHERE id=?", (p["loan_id"],)).fetchone(); v = loan_view(c, l, s)
    c.execute("UPDATE loans SET penalty_charged=? WHERE id=?", (v["penalty_charged"], l["id"]))
    split = engine.allocate(v["outstanding"], p["amount"], s["alloc_order"])
    for k, a in split.items():
        if a: c.execute("INSERT INTO allocations(payment_id,bucket,amount) VALUES(?,?,?)", (pid, k, a))
    c.execute("UPDATE payments SET status='SUCCESS' WHERE id=?", (pid,))
    rno = db.next_no(c, "receipt", "R"); c.execute("INSERT INTO receipts(no,payment_id) VALUES(?,?)", (rno, pid))
    bal = loan_view(c, l, s)["outstanding"]["total"]; c.execute("UPDATE payments SET balance_after=? WHERE id=?", (bal, pid))
    db.audit(c, uid, "PAYMENT_RECORDED", rno, json.dumps(dict(split, method=p["method"], mode=p["mode"]))); notify_paid(c, l, p, rno, bal); return dict(receipt=rno, allocation=split, balance=bal)

def notify_paid(c, l, p, rno, bal):
    notify.customer(c, l["customer_id"], "payment_received", "Payment received", f"We received {M(p['amount'])} on loan {l['no']} (receipt {rno}). Remaining balance {M(bal)}.")
    if bal <= 0: notify.customer(c, l["customer_id"], "loan_cleared", "Loan cleared", f"Loan {l['no']} is fully paid. Thank you!")
    notify.staff(c, ("admin",), "payment_received", "Payment received", f"{M(p['amount'])} on {l['no']} via {p['method']} ({rno})")

def handle_event(c, ev, s, loan_view, uid=None):
    """Single entry point for provider callbacks (real webhook or sandbox). Duplicate event ids are ignored."""
    try: c.execute("INSERT INTO webhook_events(id) VALUES(?)", (str(ev["event_id"]),))
    except sqlite3.IntegrityError: return dict(status="DUPLICATE")
    p = c.execute("SELECT * FROM payments WHERE reference=?", (ev.get("reference"),)).fetchone()
    if not p: raise ValueError("Unknown payment reference")
    if p["status"] != "PENDING": return dict(status=p["status"])
    if ev.get("status") == "success": return dict(status="SUCCESS", **settle(c, p["id"], s, loan_view, uid))
    if ev.get("status") == "failed":
        c.execute("UPDATE payments SET status='FAILED' WHERE id=?", (p["id"],)); db.audit(c, uid, "PAYMENT_FAILED", p["reference"], p["method"]); ln = c.execute("SELECT * FROM loans WHERE id=?", (p["loan_id"],)).fetchone()
        notify.customer(c, ln["customer_id"], "payment_failed", "Payment failed", f"Your payment of {M(p['amount'])} on loan {ln['no']} could not be processed. Please try again.")
        notify.staff(c, ("admin", "cashier"), "payment_failed", "Failed payment", f"{M(p['amount'])} on {ln['no']} ({p['reference']})"); return dict(status="FAILED")
    raise ValueError("Invalid event status")

def create(c, u, b, s, loan_view, online):
    l = c.execute("SELECT * FROM loans WHERE id=?", (b.get("loan_id"),)).fetchone()
    if not l: raise ValueError("Loan not found")
    if u["role"] == "customer":
        if c.execute("SELECT customer_id FROM users WHERE id=?", (u["id"],)).fetchone()[0] != l["customer_id"]: raise PermissionError("Insufficient permissions")
    try: amt = round(float(b.get("amount") or 0) * 100)
    except (TypeError, ValueError): raise ValueError("Invalid amount")
    if amt <= 0: raise ValueError("Payment amount must be greater than zero")
    owing = loan_view(c, l, s)["outstanding"]["total"]
    if owing <= 0: raise ValueError("Loan is already cleared")
    if amt > owing: raise ValueError(f"Amount exceeds the outstanding balance of {M(owing)}")
    ref = str(b.get("reference") or secrets.token_hex(6))[:60]
    if c.execute("SELECT 1 FROM payments WHERE reference=?", (ref,)).fetchone(): raise ValueError("Duplicate payment reference")
    mode = get(c, "payment_mode", "test"); prov = ""
    if online:
        prov = (Sandbox() if mode == "test" else Live()).initiate(ref); method = "Online gateway"
    else:
        method = b.get("method", "Cash")
        if method not in get(c, "payment_methods", DEFAULT_METHODS): raise ValueError("Payment method is not enabled")
    pid = c.execute("INSERT INTO payments(loan_id,amount,method,reference,status,user_id,provider_ref,mode) VALUES(?,?,?,?,'PENDING',?,?,?)", (l["id"], amt, method, ref, u["id"], prov, mode)).lastrowid
    if not online: return dict(status="SUCCESS", reference=ref, **settle(c, pid, s, loan_view, u["id"]))
    sc = b.get("scenario", "success") if mode == "test" else "pending"   # scenarios exist only in TEST mode
    if sc not in ("success", "failed", "pending"): raise ValueError("Invalid test scenario")
    if sc == "pending": return dict(status="PENDING", reference=ref)
    return dict(reference=ref, **handle_event(c, dict(event_id=f"sbx-{ref}-{sc}", reference=ref, status=sc), s, loan_view, u["id"]))

def create_proof(c, u, b, s, loan_view):
    """Customer paid by bank transfer (EFT) and uploads proof; staff confirm against the bank statement before it is allocated."""
    import base64
    from portal import MAGIC, UP
    l = c.execute("SELECT * FROM loans WHERE id=?", (b.get("loan_id"),)).fetchone()
    if not l or c.execute("SELECT customer_id FROM users WHERE id=?", (u["id"],)).fetchone()[0] != l["customer_id"]: raise PermissionError("Insufficient permissions")
    try: amt = round(float(b.get("amount")) * 100)
    except (TypeError, ValueError): raise ValueError("Invalid amount")
    owing = loan_view(c, l, s)["outstanding"]["total"]
    if amt <= 0: raise ValueError("Payment amount must be greater than zero")
    if owing <= 0: raise ValueError("Loan is already cleared")
    if amt > owing: raise ValueError(f"Amount exceeds the outstanding balance of {M(owing)}")
    try: raw = base64.b64decode(b.get("doc", ""), validate=True)
    except Exception: raw = b""
    if not raw: raise ValueError("Please attach your proof of payment")
    mime = next((v for mg, v in MAGIC.items() if raw.startswith(mg)), None)
    if not mime or len(raw) > 5_000_000: raise ValueError("Proof must be a JPG, PNG or PDF up to 5MB")
    os.makedirs(UP, exist_ok=True); stored = secrets.token_hex(16); open(os.path.join(UP, stored), "wb").write(raw)
    ref = "EFT-" + secrets.token_hex(4).upper(); name = re.sub(r"[^\w.\-]", "_", str(b.get("doc_name", "proof")))[:80]
    c.execute("INSERT INTO payments(loan_id,amount,method,reference,status,user_id,mode,proof_stored,proof_mime,proof_name) VALUES(?,?,'EFT',?,'PENDING',?,?,?,?,?)", (l["id"], amt, ref, u["id"], get(c, "payment_mode", "test"), stored, mime, name))
    notify.customer(c, l["customer_id"], "proof_received", "Proof of payment received", f"We received your proof for {M(amt)} on loan {l['no']}. We will confirm it shortly.")
    notify.staff(c, ("admin", "cashier"), "payment_proof", "Payment proof to review", f"{M(amt)} on {l['no']} ({ref})"); db.audit(c, u["id"], "PAYMENT_PROOF_SUBMITTED", ref, M(amt))
    return dict(status="PENDING", reference=ref)

def route(h, c, m, path, b, s, loan_view):
    if path == "/api/payments/bank-details":
        if m == "POST":
            u = h.need("settings"); put(c, "bank_details", {k: str(b.get(k, ""))[:120] for k in DEFAULT_BANK}); db.audit(c, u["id"], "BANK_DETAILS_CHANGED", "payments")
        else: h.need("payments")
        h.send(200, get(c, "bank_details", DEFAULT_BANK)); return True
    if path == "/api/payments/proof" and m == "POST":
        u = h.user()
        if not u or u["role"] != "customer": raise PermissionError("Insufficient permissions")
        h.send(200, create_proof(c, u, b, s, loan_view)); return True
    if path == "/api/payments/proofs" and m == "GET":
        h.need("payments"); h.send(200, [dict(r) for r in c.execute("SELECT p.id,p.amount,p.reference,date(p.created) d,l.no lno,cu.name cname FROM payments p JOIN loans l ON l.id=p.loan_id JOIN customers cu ON cu.id=l.customer_id WHERE p.status='PENDING' AND p.proof_stored IS NOT NULL ORDER BY p.id")]); return True
    mm = re.fullmatch(r"/api/payments/(\d+)/(proof|review)", path)
    if mm:
        p = c.execute("SELECT p.*,l.customer_id FROM payments p JOIN loans l ON l.id=p.loan_id WHERE p.id=? AND p.proof_stored IS NOT NULL", (mm[1],)).fetchone()
        if not p: raise ValueError("Payment proof not found")
        u = h.user()
        if not u: raise PermissionError("Please log in")
        if mm[2] == "proof":
            if u["role"] == "customer":
                if c.execute("SELECT customer_id FROM users WHERE id=?", (u["id"],)).fetchone()[0] != p["customer_id"]: raise PermissionError("Insufficient permissions")
            else: h.need("payments")
            from portal import UP
            h.send(200, open(os.path.join(UP, p["proof_stored"]), "rb").read(), p["proof_mime"]); return True
        u = h.need("payments")
        if p["status"] != "PENDING": raise ValueError("This payment has already been reviewed")
        ln = c.execute("SELECT * FROM loans WHERE id=?", (p["loan_id"],)).fetchone()
        if b.get("decision") == "approve":
            if p["amount"] > loan_view(c, ln, s)["outstanding"]["total"]: raise ValueError("Amount exceeds the outstanding balance")
            h.send(200, dict(status="SUCCESS", **settle(c, p["id"], s, loan_view, u["id"]))); return True
        if b.get("decision") == "reject":
            if not str(b.get("reason", "")).strip(): raise ValueError("A reason is required")
            c.execute("UPDATE payments SET status='FAILED' WHERE id=?", (p["id"],)); db.audit(c, u["id"], "PAYMENT_PROOF_REJECTED", p["reference"], str(b["reason"])[:200])
            notify.customer(c, ln["customer_id"], "payment_failed", "Proof of payment not accepted", f"Your proof for {M(p['amount'])} on loan {ln['no']} was not accepted. Reason: {str(b['reason'])[:200]}"); h.send(200, dict(status="FAILED")); return True
        raise ValueError("Invalid decision")
    if path == "/api/payments/webhook" and m == "POST":     # called by the provider, no login; authenticated by signature
        if not hmac.compare_digest(h.headers.get("X-Signature", ""), sign(b)): raise PermissionError("Invalid signature")
        h.send(200, handle_event(c, b, s, loan_view)); return True
    if path == "/api/payments/online" and m == "POST":
        u = h.user()
        if not u: raise PermissionError("Please log in")
        if u["role"] != "customer": h.need("payments")
        h.send(200, create(c, u, b, s, loan_view, True)); return True
    if path == "/api/payments" and m == "POST":
        h.send(200, create(c, h.need("payments"), b, s, loan_view, False)); return True
    if path == "/api/payments" and m == "GET":
        h.need("payments"); h.send(200, [dict(r) for r in c.execute("SELECT p.id,p.amount,p.method,p.reference,p.status,p.mode,p.created,l.no lno,cu.name cname FROM payments p JOIN loans l ON l.id=p.loan_id JOIN customers cu ON cu.id=l.customer_id ORDER BY p.id DESC LIMIT 30")]); return True
    if path == "/api/payments/sandbox/resolve" and m == "POST":
        u = h.need("payments"); p = c.execute("SELECT * FROM payments WHERE reference=?", (b.get("reference"),)).fetchone()
        if not p or p["mode"] != "test" or p["method"] != "Online gateway": raise ValueError("Only TEST gateway payments can be resolved manually")
        h.send(200, handle_event(c, dict(event_id=f"sbx-{p['reference']}-{b.get('outcome')}", reference=p["reference"], status=b.get("outcome")), s, loan_view, u["id"])); return True
    if path == "/api/payments/config":
        if m == "POST":
            u = h.need("settings")
            if b.get("mode") not in ("test", "live"): raise ValueError("Mode must be test or live")
            if b.get("credentials"): put(c, "payment_credentials", b["credentials"])           # stored server-side, never returned
            if b["mode"] == "live" and not get(c, "payment_credentials"): raise ValueError("Enter live merchant credentials before switching to LIVE")
            put(c, "payment_mode", b["mode"])
            if b.get("methods"): put(c, "payment_methods", [str(x)[:40] for x in b["methods"]])
            db.audit(c, u["id"], "PAYMENT_CONFIG_CHANGED", b["mode"])
        else: h.need("payments")
        h.send(200, dict(mode=get(c, "payment_mode", "test"), methods=get(c, "payment_methods", DEFAULT_METHODS), live_credentials_configured=bool(get(c, "payment_credentials")))); return True
    if path == "/api/cashier/search":
        h.need("payments"); q = parse_qs(urlparse(h.path).query).get("q", [""])[0].strip()
        if len(q) < 2: return h.send(200, []) or True
        like = f"%{q}%"; out = []
        for cu in c.execute("SELECT DISTINCT cu.* FROM customers cu LEFT JOIN loans l ON l.customer_id=cu.id WHERE cu.name LIKE ? OR cu.id_number LIKE ? OR cu.phone LIKE ? OR cu.no LIKE ? OR l.no LIKE ? LIMIT 10", (like,) * 5):
            ls = [loan_view(c, r, s) for r in c.execute("SELECT * FROM loans WHERE customer_id=?", (cu["id"],))]
            out.append(dict(id=cu["id"], no=cu["no"], name=cu["name"], loans=[dict(id=v["id"], no=v["no"], status=v["status"], outstanding=v["outstanding"]) for v in ls if v["status"] != "CLEARED"]))
        h.send(200, out); return True
    return False
