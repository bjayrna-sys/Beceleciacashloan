import sqlite3, os, json, hashlib, secrets
from engine import DEFAULTS
PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "database", "becelecia.db"))
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT, role TEXT NOT NULL, pw TEXT NOT NULL, active INT DEFAULT 1, customer_id INT, twofa INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, no TEXT UNIQUE, name TEXT NOT NULL, id_number TEXT UNIQUE NOT NULL, phone TEXT, employer TEXT, salary_cents INT DEFAULT 0, blacklisted INT DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY, no TEXT UNIQUE, customer_id INT NOT NULL REFERENCES customers(id), principal INT, interest INT, levy INT, fees INT, total INT, due_date TEXT, frequency TEXT, investor_share INT, stamp INT DEFAULT 0, bank INT DEFAULT 0, status TEXT DEFAULT 'ACTIVE', penalty_charged INT DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS schedule(id INTEGER PRIMARY KEY, loan_id INT REFERENCES loans(id), no INT, due TEXT, amount INT);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, loan_id INT NOT NULL REFERENCES loans(id), amount INT NOT NULL CHECK(amount>0), method TEXT, reference TEXT UNIQUE, status TEXT DEFAULT 'SUCCESS', balance_after INT, provider_ref TEXT, mode TEXT DEFAULT 'test', proof_stored TEXT, proof_mime TEXT, proof_name TEXT, user_id INT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS allocations(id INTEGER PRIMARY KEY, payment_id INT REFERENCES payments(id), bucket TEXT, amount INT);
CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY, no TEXT UNIQUE, payment_id INT UNIQUE REFERENCES payments(id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user_id INT, action TEXT, record TEXT, detail TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY, no TEXT UNIQUE, customer_id INT NOT NULL REFERENCES customers(id), amount INT, days INT, frequency TEXT, employer TEXT, salary_cents INT, expenses_cents INT, other_loans_cents INT, total_due INT, score TEXT, status TEXT DEFAULT 'SUBMITTED', reason TEXT, loan_no TEXT, decided_by INT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers(id), kind TEXT, filename TEXT, stored TEXT UNIQUE, mime TEXT, verified INT DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS webhook_events(id TEXT PRIMARY KEY, at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INT NOT NULL REFERENCES users(id), kind TEXT, title TEXT, body TEXT, read INT DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS ix_notif_user ON notifications(user_id, read);
CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY, channel TEXT, to_addr TEXT, subject TEXT, body TEXT, status TEXT, attempts INT DEFAULT 0, error TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reminder_log(loan_id INT, inst_no INT, rule TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(loan_id, inst_no, rule));
CREATE TABLE IF NOT EXISTS investors(id INTEGER PRIMARY KEY, user_id INT UNIQUE REFERENCES users(id), name TEXT NOT NULL, email TEXT, phone TEXT, active INT DEFAULT 1, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS investor_tx(id INTEGER PRIMARY KEY, investor_id INT NOT NULL REFERENCES investors(id), kind TEXT NOT NULL CHECK(kind IN ('DEPOSIT','WITHDRAWAL')), amount INT NOT NULL CHECK(amount>0), note TEXT, user_id INT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS investor_alloc(id INTEGER PRIMARY KEY, investor_id INT NOT NULL REFERENCES investors(id), loan_id INT NOT NULL REFERENCES loans(id), amount INT NOT NULL CHECK(amount>0), created TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(investor_id, loan_id));
CREATE TABLE IF NOT EXISTS expense_categories(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, date TEXT NOT NULL, category_id INT NOT NULL REFERENCES expense_categories(id), payee TEXT, amount INT NOT NULL CHECK(amount>0), description TEXT, method TEXT, reference TEXT, doc_stored TEXT, doc_mime TEXT, doc_name TEXT, user_id INT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS ix_exp_date ON expenses(date);
CREATE TABLE IF NOT EXISTS cash_transactions(id INTEGER PRIMARY KEY, date TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('IN','OUT')), account TEXT NOT NULL CHECK(account IN ('CASH','BANK')), amount INT NOT NULL CHECK(amount>0), category TEXT, description TEXT, reference TEXT, loan_id INT REFERENCES loans(id), user_id INT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reconciliations(id INTEGER PRIMARY KEY, date TEXT, statement_balance INT, system_balance INT, difference INT, note TEXT, user_id INT, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS blacklist_entries(id INTEGER PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers(id), reason TEXT NOT NULL, notes TEXT, doc_stored TEXT, doc_mime TEXT, doc_name TEXT, added_by INT, added_at TEXT DEFAULT CURRENT_TIMESTAMP, active INT DEFAULT 1, removed_by INT, removed_at TEXT, removal_reason TEXT);
CREATE INDEX IF NOT EXISTS ix_bl_cust ON blacklist_entries(customer_id, active);
CREATE TABLE IF NOT EXISTS otp_codes(id INTEGER PRIMARY KEY, user_id INT NOT NULL REFERENCES users(id), purpose TEXT NOT NULL, token TEXT UNIQUE, code_hash TEXT, expires TEXT, attempts INT DEFAULT 0, used INT DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS counters(name TEXT PRIMARY KEY, n INT);
"""
def conn():
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    c = sqlite3.connect(PATH); c.row_factory = sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c
def hpw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200000).hex()
def check(pw, stored): return secrets.compare_digest(hpw(pw, stored.split("$")[0]), stored)
def next_no(c, name, prefix, width=4):
    c.execute("INSERT OR IGNORE INTO counters VALUES(?,0)", (name,)); c.execute("UPDATE counters SET n=n+1 WHERE name=?", (name,))
    return prefix + str(c.execute("SELECT n FROM counters WHERE name=?", (name,)).fetchone()[0]).zfill(width)
def settings(c):
    s = dict(DEFAULTS)
    for r in c.execute("SELECT key,value FROM settings"): s[r["key"]] = json.loads(r["value"])
    return s
def audit(c, uid, action, record, detail=""): c.execute("INSERT INTO audit(user_id,action,record,detail) VALUES(?,?,?,?)", (uid, action, record, detail))
def init():
    c = conn(); c.executescript(SCHEMA)
    if not c.execute("SELECT 1 FROM users").fetchone():   # DEMO DATA
        for e, n, r in [("admin@demo.com","DEMO Admin","admin"),("cashier@demo.com","DEMO Cashier","cashier"),("officer@demo.com","DEMO Loan Officer","loan_officer"),("accountant@demo.com","DEMO Accountant","accountant")]:
            c.execute("INSERT INTO users(email,name,role,pw) VALUES(?,?,?,?)", (e, n, r, hpw("Demo@1234")))
    for n in ("Rent", "Electricity", "Water", "WIFI", "Collexia", "Transport", "Fuel", "Other"): c.execute("INSERT OR IGNORE INTO expense_categories(name) VALUES(?)", (n,))
    c.commit(); c.close()
