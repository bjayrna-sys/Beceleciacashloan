"""Emergency tools for the server owner (run on the server, never exposed on the web).
  python3 recover.py disable-forced-2fa          switch off the 'required 2-step login' policy (use if email stops working and admins are locked out)
  python3 recover.py reset-password EMAIL         set a new password for a user (asks for it; or set RECOVER_PASSWORD)"""
import getpass, os, sys
import db
from users_api import strong
def main():
    a = sys.argv[1:]
    if not a or a[0] not in ("disable-forced-2fa", "reset-password"): sys.exit(__doc__)
    c = db.conn()
    if a[0] == "disable-forced-2fa":
        c.execute("INSERT OR REPLACE INTO settings VALUES('require_2fa','\"off\"')"); c.execute("UPDATE users SET twofa=0 WHERE role!='customer'"); db.audit(c, None, "SETTING_CHANGED", "require_2fa", "off (server recovery)"); print("Required 2-step login is now off, and staff 2-step logins are reset.")
    else:
        if len(a) < 2: sys.exit("Give the user's email address")
        u = c.execute("SELECT id FROM users WHERE email=?", (a[1].strip().lower(),)).fetchone() or sys.exit("No such user")
        pw = os.environ.get("RECOVER_PASSWORD") or getpass.getpass("New password: ")
        try: strong(pw)
        except ValueError as e: sys.exit(str(e))
        c.execute("UPDATE users SET pw=? WHERE id=?", (db.hpw(pw), u["id"])); db.audit(c, None, "PASSWORD_RESET", a[1], "by server recovery tool"); print("Password changed.")
    c.commit()
if __name__ == "__main__": main()
