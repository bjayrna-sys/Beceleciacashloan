"""Public (no login) endpoints for the website: current loan terms and a server-side loan quote."""
from urllib.parse import urlparse, parse_qs
import engine
def route(h, c, m, path, b, s, loan_view):
    if path == "/api/health":
        c.execute("SELECT 1"); h.send(200, dict(status="ok")); return True
    if path == "/api/public/products":
        h.send(200, dict(min_amount=s["min_cents"] // 100, max_amount=s["max_cents"] // 100, min_days=s["min_days"], max_days=s["max_days"], interest_pct=round(s["rate_monthly"] * 100, 2),
                         grace_days=s["grace_days"], penalty_pct=round(s["penalty_pct"] * 100, 2), penalty_max_months=s["penalty_max_months"], frequencies=list(engine.STEP))); return True
    if path == "/api/public/quote":
        q = {k: v[0] for k, v in parse_qs(urlparse(h.path).query).items()}
        try: p, d = round(float(q.get("amount")) * 100), int(q.get("days"))
        except (TypeError, ValueError): raise ValueError("Enter a valid amount and number of days")
        x = engine.quote(p, d, q.get("frequency", "weekly"), s)
        h.send(200, dict(amount=p, interest=x["interest"], charges=x["fees"] + x["lv"] if "lv" in x else x["fees"] + x["levy"], total=x["total"], instalments=len(x["schedule"]), instalment=x["schedule"][0]["amount"], due_date=x["due_date"])); return True
    return False
